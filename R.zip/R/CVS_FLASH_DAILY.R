library ("httr")
library ("RSiteCatalyst")
library ("base64enc")
library ("jsonlite")
library ("plyr")
library ("stringi")
library ("curl")
library ("xml2")
library ("RCurl")
library ("openssl")

rm(list = ls())
setwd("/home/ronxu/apipulldata")

lp=1

dtt=Sys.Date()-lp

cdtt=paste0("date'",dtt,"'")
dcdtt=paste(cdtt,",", collapse="")
dcdttc=substr(dcdtt,1,nchar(dcdtt)-1)

#####################
# Loading the RODBC Package
#####################
library(RODBC)

Sys.setenv(ODBCINI = "/opt/teradata/client/ODBC_64/odbc.ini")

Sys.setenv(PATH = "/opt/teradata/client/16.00/bin:/usr/local/sbin:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.131-3.b12.el7_3.x86_64/bin:/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/bin:/opt/teradata/client/ODBC_64:/usr/local/bin")

driver='/opt/teradata/client/ODBC_64/lib/tdata.so'
user='cea_user'
password='makem0ney4cvs'
channel<-odbcConnect("testpbm",uid= user,pwd=password) 


adobesql=paste0("select sum(case when BU='CVS' and platform='dweb'  then Auth_login else 0 end) as Desktop_Traffic,
                sum(case when BU='CVS' and platform='dweb'  then order_confirm else 0 end) as Desktop_Orders,
                sum(case when BU='CVS' and platform='dweb'  then RX_RTL else 0 end) as Desktop_Refills,
                sum(case when BU='CVS' and platform in ('mweb','tweb')  then Auth_login else 0 end) as mWeb_Traffic,
                sum(case when BU='CVS' and platform in ('mweb','tweb')  then order_confirm else 0 end) as mWeb_Orders,
                sum(case when BU='CVS' and platform in ('mweb','tweb')  then RX_RTL else 0 end) as mWeb_Refills,
                sum(case when BU='CVS' and platform='mapp'  then Auth_login else 0 end) as App_Traffic,
                sum(case when BU='CVS' and platform='mapp'  then order_confirm else 0 end) as App_Orders,
                sum(case when BU='CVS' and platform='mapp'  then RX_RTL else 0 end) as App_Refills,
                sum(case when BU='CVS'   then auth_complete else 0 end) as Auth_Complete
                from  DSS_CEA2.YZ_ALL_MTS_HOUR where HR between 0 and 23 and dt in (", dcdttc,  ")" )
adobesql=gsub("[\r\n]", " ", adobesql)
table1=sqlQuery(channel, adobesql)
close(channel)

library(RODBC)

Sys.setenv(ODBCINI = "/opt/teradata/client/ODBC_64/odbc.ini")

Sys.setenv(PATH = "/opt/teradata/client/16.00/bin:/usr/local/sbin:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.131-3.b12.el7_3.x86_64/bin:/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/bin:/opt/teradata/client/ODBC_64:/usr/local/bin")

driver='/opt/teradata/client/ODBC_64/lib/tdata.so'
user='RKALAPATAPU'
password='Monday_1'
ch<-odbcConnect("testfs",uid= user,pwd=password) 

essql=paste0("
             select at_ts(date) as Report_Date, sum(1) as ES_Refills
             from p_ent.localytic_event_custom A 
             where name = 'easy scan' and key_name='refill success'  and value_txt='yes'
             and at_ts(date) =", dcdttc,  "group by 1" )
essql=gsub("[\r\n]", " ", essql)
table2=sqlQuery(ch, essql)
close(ch)

c1="Caremark\\zongy"
c2="Rondontgo_123"

baseurl1 <- paste0("https://ws.webtrends.com/v3/Reporting/profiles/88296/reports/j4GQHWkwWI7/?totals=only&start_period=current_day-",lp,"&end_period=current_day-",lp,"&period_type=indv&search=ICET-&measures=16&format=csv&suppress_error_codes=true")
cleand1<-GET(baseurl1, authenticate(c1, c2))
a1=data.frame(httr::content(cleand1 ))[,4]

baseurl2 <-paste0("https://ws.webtrends.com/v3/Reporting/profiles/88296/reports/qu4AeIZNCj7/?totals=only&start_period=current_day-",lp,"&end_period=current_day-",lp,"&period_type=indv&search=ICET-&measures=16&format=csv&suppress_error_codes=true")
cleand2<-GET(baseurl2, authenticate(c1, c2))
a2=data.frame(httr::content(cleand2 ))[,4]

baseurl3 <-paste0("https://ws.webtrends.com/v3/Reporting/profiles/88296/reports/iEiJVJgwWI7/?totals=only&start_period=current_day-",lp,"&end_period=current_day-",lp,"&period_type=indv&search=ICET-&measures=16&format=csv&suppress_error_codes=true")
cleand3<-GET(baseurl3, authenticate(c1, c2))
a3=data.frame(httr::content(cleand3 ))[,4]

Rapid_fill=sum(a1,a2,a3)

if(nrow(table2)>0){
  esr=table2$ES_Refills
  
}else(
  esr=0
)


daily=data.frame(dtt,table1,0,esr,Rapid_fill)
names(daily)[1]="DT"
names(daily)[12]="Ipad_Fills"
names(daily)[13]="ES_Refills"
names(daily)[14]="Rapid_Fills"


daily=daily[,c(1:10,12:14,11)]


####################################################
#################Minor Approval
####################################################

#################
##Localytics
#################

#############################
##Web Trend
#############################

baseurl1 <- paste0("https://ws.webtrends.com/v3/Reporting/profiles/104228/reports/9e20MjGoRm7/?totals=only&start_period=current_day-",lp,"&end_period=current_day-",lp,"&period_type=indv&measures=1&format=csv&suppress_error_codes=true")
cleand1<-GET(baseurl1, authenticate(c1, c2))
ma_a1=data.frame(httr::content(cleand1 ))[,4]

daily$Minor_Approvals=ma_a1


####################################################################
# SMS_Auth
####################################################################

SCAuth("yzong:CVS Health","ba9be9678ba82cfad06913cab927ef1e",company="CVS Health")
sms1 <- QueueTrended("cvshealthretailprod",
                      dtt,
                      dtt,
                      c("cm300002782_59bfcd11f73f236a1f5a2627" ),
                      c("eVar83") , 
                      date.granularity = "day"
)


sms2 <- QueueTrended("cvshealthretailprod",
                      dtt,
                      dtt,
                      c("cm300002782_5a78a4d8b7204e6c8eb6291f" ),
                      c("eVar83") , segment.id = "s300002782_5a737cb2c912bb2df881c92b" ,
                      date.granularity = "day"
)

daily$SMS_Auth=round(0.75*sum(sms1[,4]) )+sum(sms2[,4])

#####################
# Loading the RODBC Package
#####################
library(RODBC)

Sys.setenv(ODBCINI = "/opt/teradata/client/ODBC_64/odbc.ini")

Sys.setenv(PATH = "/opt/teradata/client/16.00/bin:/usr/local/sbin:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.131-3.b12.el7_3.x86_64/bin:/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/bin:/opt/teradata/client/ODBC_64:/usr/local/bin")

driver='/opt/teradata/client/ODBC_64/lib/tdata.so'
user='cea_user'
password='makem0ney4cvs'
channel<-odbcConnect("testpbm",uid= user,pwd=password) 


####################
# ReadyFill Enrolled Rx
####################
RFsql=paste0("select t1.crte_dt as DT, count(distinct t3.ECCA_RFRNC_KEY_NBR) as RF_Enroll_Rx
from DWU_EDW.V_ECCA_INTRCTN t1
JOIN DWU_EDW.V_ECCA_MBR_TRX_DENORM t3 
on t1.INTRCTN_KEY_ID=t3.INTRCTN_KEY_ID and t3.ECCA_RFRNC_KEY_ID = 'RX_NUM'
where t1.crte_dt between date-2-1 and date-1
and t1.INTRCTN_TYP_CD in ('7104','7101','7100')
and t1.INTRCTN_RSLT_CD = 'COMPLETED'
group by 1
order by 1" )

RFRxsql <- sqlQuery(channel, RFsql)
daily$RF_Enroll_Rx=RFRxsql$RF_Enroll_Rx[3]

SQ11=paste0("UPDATE DSS_CEA2.YZ_CVS_FLASH_DAILY SET RF_Enroll_Rx=",RFRxsql$RF_Enroll_Rx[1]," where DT=date'",RFRxsql$DT[1],"'")
SQ12=paste0("UPDATE DSS_CEA2.YZ_CVS_FLASH_DAILY SET RF_Enroll_Rx=",RFRxsql$RF_Enroll_Rx[2]," where DT=date'",RFRxsql$DT[2],"'")

sqlQuery(channel, SQ11)
sqlQuery(channel, SQ12)

####################
# Delete 24 hours
####################
deletesql=paste0("Delete from DSS_CEA2.YZ_CVS_FLASH_DAILY where dt in (", dcdttc,  ")" )

sqlQuery(channel, deletesql)


#####################
# Write to teradata table(s)
#####################

sqlSave(channel, daily , tablename = "DSS_CEA2.YZ_CVS_FLASH_DAILY",rownames=FALSE, append=TRUE,fast = T,verbose=T)

close(channel)
