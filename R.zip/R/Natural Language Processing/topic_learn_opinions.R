
files <- readLines("C:/Users/c005321/Documents/Twitter/RTextMining/data/Opiniolabs_only.csv")

files<-files[-1]

fname<-paste0('op',   sprintf("%03d",(1:length(files)))  )

require.package("stringr")
require.package("tm")
fwords<-str_count(files ,  "\\S+")


docs <- Corpus(VectorSource(files))


length(docs)

#inspect a particular document in corpus
#writeLines(as.character(docs[[3]]))

################################
########start preprocessing#####
################################
#Transform to lower case
docs <-tm_map(docs,content_transformer(tolower))
 

#remove punctuation
docs <- tm_map(docs, removePunctuation)
#Strip digits
docs <- tm_map(docs, removeNumbers)
#remove whitespace
docs <- tm_map(docs, stripWhitespace)




#Good practice to check every now and then
writeLines(as.character(docs[[1]]))
#Stem document
docs <- tm_map(docs,stemDocument)


#fix up 1) differences between us and aussie english 2) general errors
docs <- tm_map(docs, content_transformer(gsub),
               pattern = "thx", replacement = "thank")
#define and eliminate all custom stopwords



#remove stopwords
docs <- tm_map(docs, removeWords, stopwords("english"))
rm_words <- readLines(system.file("stopwords", "english.dat",package = "tm"))
rm_words <- c(rm_words,"rt",'can','just','amp','want',"cvs",
        "can", "say","one","way","use",
     "also","howev","tell","will",
     "much","need","take","tend","even",
     "like","particular","rather","said",
     "get","well","make","ask","come","end",
     "first","two","help","often","may",
     "might","see","someth","thing","point",
     "post","look","right","now","think","'ve ",
     "'re ","anoth","put","set","new","good",
     "want","sure","kind","larg","yes,","day","etc",
     "quit","sinc","attempt","lack","seen","awar",
     "littl","ever","moreov","though","found","abl",
     "enough","far","earli","away","achiev","draw",
     "last","never","brief","bit","entir","brief",
     "great","lot","dont","cant","told","thank",
     "pleas","becaus","know","veri")

docs <- tm_map(docs, removeWords, rm_words)


#Create document-term matrix
dtm <- DocumentTermMatrix(docs)
rownames(dtm) <- fname

fname[fwords<3]
dtm<-dtm[fwords>=3,]
dim(dtm)

zerorow <- rowSums(as.matrix(dtm))
length(zerorow)
dtm<-dtm[zerorow!=0,]


dim(dtm)


#inspect a document as a check
writeLines(as.character(docs[[34]]))

#convert rownames to filenames
#rownames(dtm) <- filenames
#collapse matrix by summing over columns
#freq <- colSums(as.matrix(dtm))
#length should be total number of terms
#length(freq)
#create sort order (descending)
#ord <- order(freq,decreasing=TRUE)
#List all terms in decreasing order of freq and write to disk
#freq[ord]

install.packages('topicmodels')
library(topicmodels)


#Set parameters for Gibbs sampling
burnin <- 4000
iter <- 2000
thin <- 500
seed <-list(2003,5,63,100001,765)
nstart <- 5
best <- TRUE


#Number of topics
k <- 5
#That done, we can now do the actual work - run the topic modelling algorithm on our corpus. Here is the code:

#Run LDA using Gibbs sampling
ldaOut <-LDA(dtm,k, method="Gibbs", 
             control=list(alpha = 0.1))

ldaOut <-LDA(dtm,k, method="Gibbs", control=list(nstart=nstart, seed = seed, best=best, burnin = burnin, iter = iter, thin=thin))


#write out results
#docs to topics
ldaOut.topics <- as.matrix(topics(ldaOut))
#write.csv(ldaOut.topics,file=paste("LDAGibbs",k,"DocsToTopics.csv"))


#top 6 terms in each topic
ldaOut.terms <- as.matrix(terms(ldaOut,10))
ldaOut.terms

write.csv(cbind(files[fname %in% rownames(dtm)],ldaOut.topics),
          "C:/Users/c005321/Documents/Twitter/RTextMining/data/Opiniolabs_topics.csv")


#Topic 1   Topic 2  Topic 3   Topic 4     Topic 5   
#[1,] "app"     "tri"    "card"    "prescript" "store"   
#[2,] "call"    "coupon" "veri"    "went"      "time"    
#[3,] "account" "today"  "purchas" "refil"     "custom"  
#[4,] "pick"    "work"   "becaus"  "wait"      "item"    
#[5,] "servic"  "manag"  "know"    "easi"      "pharmaci"
#[6,] "email"   "pleas"  "problem" "befor"     "back" 



#probabilities associated with each topic assignment
topicProbabilities <- as.data.frame(ldaOut@gamma)
write.csv(topicProbabilities,file=paste("LDAGibbs",k,"TopicProbabilities.csv"))


#Find relative importance of top 2 topics
topic1ToTopic2 <- lapply(1:nrow(dtm),function(x)
  sort(topicProbabilities[x,])[k]/sort(topicProbabilities[x,])[k-1])


#Find relative importance of second and third most important topics
topic2ToTopic3 <- lapply(1:nrow(dtm),function(x)
  sort(topicProbabilities[x,])[k-1]/sort(topicProbabilities[x,])[k-2])

