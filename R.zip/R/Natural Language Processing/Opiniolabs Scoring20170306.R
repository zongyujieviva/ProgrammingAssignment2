source_code="C:/Users/c005321/Documents/R/funcs.R"
source(source_code)
require.package("plyr")
require.package("stringr")
require.package("pROC")
require.package("RTextTools")
require.package("e1071")
require.package("xgboost")
require.package("parallel")
require.package("syuzhet")


wd="C:/Users/c005321/Documents/Twitter/RTextMining/data"

setwd(wd)

DatasetCVS<-read.csv("Opiniolabs_only.csv",stringsAsFactors =F)
sentences<-DatasetCVS$op

sentences<-sapply(sentences,function(row) iconv(row, "latin1", "ASCII", mark=T))

optext<-DatasetCVS$op[!is.na(sentences)]
sentences<-sentences[!is.na(sentences)]

sentences<-gsub('[[:cntrl:]]', '', sentences)

sentences<-tolower(sentences)

#replace email address with 'email'
sentences<-gsub('\\S+@\\S+\\.\\S+', 'email', sentences)
#replace url with 'http'
sentences<-gsub('http\\S+', 'http', sentences)

puntc<-
  data.frame(
    str_count(sentences ,  "\\S+"),
    str_count(sentences ,  "_"),
    str_count(sentences ,  "!"),
    str_count(sentences ,  ":"),
    str_count(sentences ,  "\\*"),
    str_count(sentences ,  "\\?"),
    str_count(sentences ,  "\\+"),
    str_count(sentences ,  "[[:alpha:]]+"),
    str_count(sentences  ,  "@"),
    str_count(sentences  ,  "\\#"),
    str_count(sentences  ,  "\\)"),
    str_count(sentences  ,  "\\("),
    str_count(sentences   ,  "%"),
    str_count(sentences  ,  "[0-9]") 
  )

names(puntc)<-c("_words","_underline","_excl",
                "_colon","_star","_qm","_plus","_exp","_at","_hash",
                "_right","_left","_percent","_number")


sentences <- gsub('[[:punct:]]', '', sentences)



####pos word neg word############
#Download Hu & Liu's opinion lexicon from http://www.cs.uic.edu/~liub/FBS/sentiment-analysis.html
hu.liu.pos = scan('positive-words.txt', what='character', comment.char=';')
hu.liu.neg = scan('negative-words.txt', what='character', comment.char=';')

pos.words = unique(c(hu.liu.pos, 'upgrade','awesom','pretti','off' ))
neg.words = unique(c(hu.liu.neg, 
                     'wtf', 'wait','waiting', 'epicfail', 'dump','disappeared',
                     'mechanical','anyway','terrify','terrifi','storm' ,'really wish'))
 

sc = laply(sentences, function(sentence, pos.words, neg.words) {
  
  # split into words. str_split is in the stringr package
  word.list = str_split(sentence, '\\s+')
  # sometimes a list() is one level of hierarchy too much
  words = unlist(word.list)
  
  # compare our words to the dictionaries of positive & negative terms
  pos.matches = match(words, pos.words)
  neg.matches = match(words, neg.words)
  
  # match() returns the position of the matched term or NA
  # we just want a TRUE/FALSE:
  pos.matches = !is.na(pos.matches)
  neg.matches = !is.na(neg.matches)
  
  # and conveniently enough, TRUE/FALSE will be treated as 1/0 by sum():
  score= list(sum(pos.matches),sum(neg.matches))
  
  return(score)
}, pos.words, neg.words, .progress="none" )


sc<-data.frame(sc)
names(sc)<-c("pos_words","neg_words")

dim(sc)#384734      2
head(sc)


#sc1<-get_sentiment(sentences)
sc2<-get_nrc_sentiment(sentences)


#####################
###word stem
####################
sentences<-stem_text(sentences)


lens<-length(sentences)
topics<-data.frame(str_count(sentences , "app |phone|install|androi"),
                   str_count(sentences , "ad |coupon|discount|on sales"),
                 
                  str_count(sentences , "manag|servic|cashier|staff|clerk|custom|min|hour|hrs|wait|time|should|wh" ),
                  str_count(sentences , "card|account|log|member" ),
                  str_count(sentences , "refil|pharmaci|script|medic"),
                  str_count(sentences , "email"),
                  str_count(sentences , "hire|job|intern")
                  )
names(topics)<-c('App','Coupon' ,'Service','Account','Pharmacy','Email','Job')

TOPIC<-rep('Other Comment',lens)

TOPIC[topics$Service>0]<-'Service' 
TOPIC[topics$Coupon>0]<-'Coupon'
TOPIC[topics$Pharmacy>0]<-'Pharmacy'
TOPIC[topics$Job>0]<-'Job'
TOPIC[topics$Account>0]<-'Account'
TOPIC[topics$App>0]<-'App'
TOPIC[topics$Email>0]<-'Email'

table(TOPIC)

wordss<-
  data.frame(str_count(sentences , "about"),
             str_count(sentences , "again"),
             str_count(sentences , "all"),
             str_count(sentences , "amp"),
             str_count(sentences , "any"),
             str_count(sentences , "aw"),
             str_count(sentences , "back"),
             str_count(sentences , "can"),
             str_count(sentences , "cant"),
             str_count(sentences , "catch"),
             str_count(sentences , "come"),
             str_count(sentences , "day"),
             str_count(sentences , "drive"),
             str_count(sentences , "enough"),
             str_count(sentences , "feel"),
             str_count(sentences , "get"),
             str_count(sentences , "goo"),
             str_count(sentences , "googl"),
             str_count(sentences , "got"),
             str_count(sentences , "ha"),
             str_count(sentences , "home"),
             str_count(sentences , "hope"),
             str_count(sentences , "http"),
             str_count(sentences , "just"),
             str_count(sentences , "know|knew"),
             str_count(sentences , "last"),
             str_count(sentences , "late"),
             str_count(sentences , "like"),
             str_count(sentences , "lol"),
             str_count(sentences , "look"),
             str_count(sentences , "love"),
             str_count(sentences , "make|made" ),
             str_count(sentences , "miss"),
             str_count(sentences , "much"),
             str_count(sentences , "need"),
             str_count(sentences , "new"),
             str_count(sentences , "night"),
             str_count(sentences , "now"), 
             str_count(sentences , "off"),
             str_count(sentences , "omg|god" ),
             str_count(sentences , "one"),
             str_count(sentences , "realli"),
             str_count(sentences , "rec"),
             str_count(sentences , "see"),
             str_count(sentences , "so"),
             str_count(sentences , "still" ),
             str_count(sentences , "thank|thx"),
             str_count(sentences , "think|thought" ),
             str_count(sentences , "time"),
             str_count(sentences , "today"),
             str_count(sentences , "tomorrow"),
             str_count(sentences , "twitter"),
             str_count(sentences , "user"),
             str_count(sentences , "want"),
             str_count(sentences , "watch"),
             str_count(sentences , "well"),
             str_count(sentences , "why"),
             str_count(sentences , "will"),
             str_count(sentences , "wish"),
             str_count(sentences , "work"),
             str_count(sentences ,  "suppose|guess"  ),
             str_count(sentences , "isnt|dont|arent|wont|wouldnt" ),
             str_count(sentences , "any more|no longer|no more" ),
             str_count(sentences , "email"),
             str_count(sentences ,"min|hour|hrs"),
             str_count(sentences ,"however|but|though"),
             str_count(sentences ,"not")
  )
#never what told
names(wordss)<-c("about","again", "all","amp", "any","aw",
                 "back","can","cant","catch",
                 "come",
                 "day",
                 "drive",
                 "enough",
                 "feel",
                 "get",
                 "goo",
                 "googl",
                 "got",
                 "ha",
                 "home",
                 "hope",
                 "http",
                 "just",
                 "know",
                 "last",
                 "late",
                 "like",
                 "lol",
                 "look",
                 "love",
                 "make",
                 "miss",
                 "much",
                 "need",
                 "new",
                 "night",
                 "now", 
                 "off",
                 "omg",
                 "one",
                 "realli",
                 "rec",
                 "see",
                 "so",
                 "still",
                 "thank",
                 "think", 
                 "time",
                 "today",
                 "tomorrow",
                 "twitter",
                 "user",
                 "want",
                 "watch",
                 "well",
                 "why",
                 "will",
                 "wish",
                 "work",
                 "suppose","isnt","nomore",'email','hmtime',"conj","not")

wordss$thank<-0#remove polite work "thank you"

dim(sc);dim(sc2[,1:8]);dim(puntc);dim(wordss)
mat<-cbind(sc, puntc,wordss)


mat[] <- lapply(mat, as.numeric) 


cat( paste( names(mat), collapse='\n' ) )

xgb_so<-readRDS("xgb_tw0303.rds")

Xm<-data.matrix( mat  )  
op_boost <- predict(xgb_so, Xm) 

op_final<-op_boost
madd<-(sc2$anger+sc2$disgust+sc2$fear+sc2$sadness)
op_final[op_boost>=0.48&op_boost<0.6 & mat$"_words">8 & madd>0]<-(op_final[op_boost>0.5&op_boost<0.6 & mat$"_words">8 & madd>0]-0.1)

length(op_final)

Emotions<-rep('Neutral',length(op_final))

Emotions[op_final<0.48 ]<-'Sadness'
Emotions[op_final<0.48 & (sc2$fear>0)]<-'Fear'
Emotions[op_final<0.48 & (sc2$disgust>0)]<-'Disgust'
Emotions[op_final<0.48 & (sc2$anger>0)]<-'Anger'

Emotions[op_final>=0.54 ]<-'Joy'
Emotions[op_final>=0.48 & (sc2$surprise>0)]<-'Surprise'
Emotions[op_final>=0.5 & (sc2$trust>0)]<-'Trust'
Emotions[op_final>=0.48 & (sc2$anticipation>0)]<-'Anticipation'

Sentiment<-rep('Neutral',length(op_final))
Sentiment[op_final<0.48]<-"Negative"
Sentiment[op_final>=0.54]<-"Positive"

output<-data.frame(cbind(optext,op_final,Sentiment,Emotions,TOPIC ))
names(output)<-c('Opinion','SentimentScore',"Sentiment","Emotion","TOPIC")

output<-arrange(output,desc(SentimentScore) )

write.csv(output, file = "Opiniolabs_scored0303.csv",row.names=FALSE, na="")


freq_table(Sentiment)
freq_table(Emotions)
freq_table(TOPIC)

