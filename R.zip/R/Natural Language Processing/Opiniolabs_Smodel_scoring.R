DatasetCVS<-read.csv("Opiniolabs_only.csv",stringsAsFactors =F)
sentences<-DatasetCVS$op



# clean up sentences with R's regex-driven global substitute, gsub():
sentences<-gsub('[[:cntrl:]]', '', sentences)
sentences<-gsub('\\d+', '', sentences)

sentences<-sapply(sentences,function(row) iconv(row, "latin1", "ASCII", sub=""))
sentences<-tolower(sentences)


puntc<-
  data.frame(
    str_count(sentences ,  "\\S+"),
    str_count(sentences ,  "_"),
    str_count(sentences ,  "!"),
    str_count(sentences ,  ":"),
    str_count(sentences ,  "\\*"),
    str_count(sentences ,  "\\?"),
    str_count(sentences ,  "\\+"),
    str_count(sentences ,  "[[:alpha:]]+"),
    str_count(sentences  ,  "@"),
    str_count(sentences  ,  "\\#"),
    str_count(sentences  ,  "\\)"),
    str_count(sentences  ,  "\\("),
    str_count(sentences   ,  "%"),
    str_count(sentences  ,  "[0-9]") 
  )

names(puntc)<-c("_words","_underline","_excl",
                "_colon","_star","_qm","_plus","_exp","_at","_hash",
                "_right","_left","_percent","_number")


sentences <- gsub('[[:punct:]]', '', sentences)




#Download Hu & Liu's opinion lexicon from http://www.cs.uic.edu/~liub/FBS/sentiment-analysis.html
hu.liu.pos = scan('positive-words.txt', what='character', comment.char=';')
hu.liu.neg = scan('negative-words.txt', what='character', comment.char=';')

pos.words = unique(c(hu.liu.pos, 'upgrade','awesom','pretti','off' ))
neg.words = unique(c(hu.liu.neg, 
                     'wtf', 'wait','waiting', 'epicfail', 'dump',
                     'mechanical','anyway','terrify','terrifi','storm' ,'really wish'))

max(pos.words %in% 'peaceful')
max(neg.words %in% 'resign')

sc = laply(sentences, function(sentence, pos.words, neg.words) {
  
  # split into words. str_split is in the stringr package
  word.list = str_split(sentence, '\\s+')
  # sometimes a list() is one level of hierarchy too much
  words = unlist(word.list)
  
  # compare our words to the dictionaries of positive & negative terms
  pos.matches = match(words, pos.words)
  neg.matches = match(words, neg.words)
  
  # match() returns the position of the matched term or NA
  # we just want a TRUE/FALSE:
  pos.matches = !is.na(pos.matches)
  neg.matches = !is.na(neg.matches)
  
  # and conveniently enough, TRUE/FALSE will be treated as 1/0 by sum():
  score= list(sum(pos.matches),sum(neg.matches))
  
  return(score)
}, pos.words, neg.words, .progress="none" )


sc<-data.frame(sc)
names(sc)<-c("pos_words","neg_words")



#####################
###word stem
####################
sentences<-stem_text(sentences)


wordss<-
  data.frame(str_count(sentences , "about"),
             str_count(sentences , "again"),
             str_count(sentences , "all"),
             str_count(sentences , "amp"),
             str_count(sentences , "any"),
             str_count(sentences , "aw"),
             str_count(sentences , "back"),
             str_count(sentences , "can"),
             str_count(sentences , "cant"),
             str_count(sentences , "catch"),
             str_count(sentences , "come"),
             str_count(sentences , "day"),
             str_count(sentences , "dont"),
             str_count(sentences , "drive"),
             str_count(sentences , "enough"),
             str_count(sentences , "feel"),
             str_count(sentences , "get"),
             str_count(sentences , "goo"),
             str_count(sentences , "googl"),
             str_count(sentences , "got"),
             str_count(sentences , "ha"),
             str_count(sentences , "home"),
             str_count(sentences , "hope"),
             str_count(sentences , "http"),
             str_count(sentences , "just"),
             str_count(sentences , "know"),
             str_count(sentences , "last"),
             str_count(sentences , "late"),
             str_count(sentences , "like"),
             str_count(sentences , "lol"),
             str_count(sentences , "look"),
             str_count(sentences , "love"),
             str_count(sentences , "make"),
             str_count(sentences , "miss"),
             str_count(sentences , "much"),
             str_count(sentences , "need"),
             str_count(sentences , "new"),
             str_count(sentences , "night"),
             str_count(sentences , "now"), 
             str_count(sentences , "off"),
             str_count(sentences , c("omg","god") ),
             str_count(sentences , "one"),
             str_count(sentences , "realli"),
             str_count(sentences , "rec"),
             str_count(sentences , "see"),
             str_count(sentences , "so"),
             str_count(sentences , "still"),
             str_count(sentences , c("thank","thx")),
             str_count(sentences , "think"),
             str_count(sentences , "though"),
             str_count(sentences , "time"),
             str_count(sentences , "today"),
             str_count(sentences , "tomorrow"),
             str_count(sentences , "twitter"),
             str_count(sentences , "user"),
             str_count(sentences , "want"),
             str_count(sentences , "watch"),
             str_count(sentences , "well"),
             str_count(sentences , "why"),
             str_count(sentences , "will"),
             str_count(sentences , "wish"),
             str_count(sentences , "work"),
             str_count(sentences , c("suppose","guess") ),
             str_count(sentences , c("isnt","dont","arent") ),
             str_count(sentences , c("any more","no longer","no more") )
             
  )

names(wordss)<-c("about","again", "all","amp", "any","aw",
                 "back","can","cant","catch",
                 "come",
                 "day",
                 "dont",
                 "drive",
                 "enough",
                 "feel",
                 "get",
                 "goo",
                 "googl",
                 "got",
                 "ha",
                 "home",
                 "hope",
                 "http",
                 "just",
                 "know",
                 "last",
                 "late",
                 "like",
                 "lol",
                 "look",
                 "love",
                 "make",
                 "miss",
                 "much",
                 "need",
                 "new",
                 "night",
                 "now", 
                 "off",
                 "omg",
                 "one",
                 "realli",
                 "rec",
                 "see",
                 "so",
                 "still",
                 "thank",
                 "think",
                 "though",
                 "time",
                 "today",
                 "tomorrow",
                 "twitter",
                 "user",
                 "want",
                 "watch",
                 "well",
                 "why",
                 "will",
                 "wish",
                 "work",
                 "suppose","isnt","nomore")



mat<-cbind(sc,puntc,wordss)



mat[] <- lapply(mat, as.numeric) 


Xm<-data.matrix( mat  )  
op_boost <- predict(xgb, Xm) 

write.csv(cbind(op_boost,DatasetCVS$op), file = "Opiniolabs_scored.csv",row.names=FALSE, na="")
