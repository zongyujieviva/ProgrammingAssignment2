require.package("Matrix")


 

clusters <- hclust(dist(dtm))
#plot(clusters)

clusterCut <- cutree(clusters, 4)

length(clusterCut)
table(clusterCut )


files[clusterCut==2]
files[clusterCut==3]
files[clusterCut==4]


setDict("C:/Users/c005321/Documents/WordNet/2.1/dict")
require.package("wordnet")

synonyms("card","NOUN")

if(initDict()) {
  filter <-  TermFilter("ExactMatchFilter", "company", TRUE)
  terms <- getIndexTerms("NOUN", 5, filter)
  getSynonyms(terms[[1]])
}
 

#k means
kfit <- kmeans(dtm, 2, nstart=100)
table(kfit$cluster)
write.csv(cbind(files[fname %in% rownames(dtm)],kfit$cluster),
          "C:/Users/c005321/Documents/Twitter/RTextMining/data/Opiniolabs_topics_cluster.csv")


#plot - need library cluster
library(cluster)
clusplot(m, kfit$cluster, color=T, shade=T, labels=2, lines=0)