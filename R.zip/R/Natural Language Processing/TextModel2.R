wd= "C:/Users/c005321/Documents/Twitter/RTextMining/data"

setwd(wd)


require.package<-function(pckg)
{
  package.installed<-try(require(pckg, character.only =TRUE))
  if (!package.installed) {
    cat(paste("Installing", pckg,  "from CRAN\n", sep=" "))
    install.packages(pckg,  repos = "http://cran.r-project.org")
    require(pckg, character.only =TRUE)
  }#if
}#require.package
require.package("plyr")
require.package("stringr")
require.package("pROC")
require.package("RTextTools")
require.package("e1071")
require.package("parallel")


stem_text<- function(text, language = "english", mc.cores = 1) {
  # stem each word in a block of text
  stem_string <- function(str, language) {
    str <- strsplit(x = str, split =, '\\s+')
     str <- wordStem(substr(unlist(str),1,254), language = language)
    str <- paste(str, collapse = " ")
    return(str)
  }
  # stem each text block in turn
  x <- mclapply(X = text, FUN = stem_string, language, mc.cores = mc.cores)
  # return stemed text blocks
  return(unlist(x))
}

freq_table<- function(yn) {
   df <- data.frame(table(yn))
   colnames(df) <- c('Value','Freq')
   df$Perc <- df$Freq / sum(df$Freq) * 100
   return(df)
}

text0<-read.csv("Sentiment Analysis Dataset.csv", header = TRUE, stringsAsFactors =FALSE)
#837106
names(text0)
text0<-text0[,-3]
names(text0)<-c('ID','sentiment','content')

text0<-text0[text0$sentiment %in% c("0","1"),]
#775557
table(text0$sentiment)
#     0      1
#403615 371942


int_ind <- rbinom(nrow(text0),1, 0.4)
text<-text0[int_ind==1,]
table(text$sentiment)

sentences<-text$content
y<-as.numeric(text$sentiment)



# clean up sentences with R's regex-driven global substitute, gsub():
sentences<-gsub('[[:cntrl:]]', '', sentences)
sentences<-gsub('\\d+', '', sentences)

sentences<-sapply(sentences,function(row) iconv(row, "latin1", "ASCII", sub=""))
sentences<-tolower(sentences)


puntc<-
  data.frame(
    str_count(sentences ,  "\\S+"),
    str_count(sentences ,  "_"),
    str_count(sentences ,  "!"),
    str_count(sentences ,  ":"),
    str_count(sentences ,  "\\*"),
    str_count(sentences ,  "\\?"),
    str_count(sentences ,  "\\+"),
    str_count(sentences ,  "[[:alpha:]]+"),
    str_count(sentences  ,  "@"),
    str_count(sentences  ,  "\\#"),
    str_count(sentences  ,  "\\)"),
    str_count(sentences  ,  "\\("),
    str_count(sentences   ,  "%"),
    str_count(sentences  ,  "[0-9]") 
  )

names(puntc)<-c("_words","_underline","_excl",
                "_colon","_star","_qm","_plus","_exp","_at","_hash",
                "_right","_left","_percent","_number")


sentences <- gsub('[[:punct:]]', '', sentences)




#Download Hu & Liu's opinion lexicon from http://www.cs.uic.edu/~liub/FBS/sentiment-analysis.html
hu.liu.pos = scan('positive-words.txt', what='character', comment.char=';')
hu.liu.neg = scan('negative-words.txt', what='character', comment.char=';')

pos.words = unique(c(hu.liu.pos, 'upgrade','awesom','pretti','off' ))
neg.words = unique(c(hu.liu.neg, 
                     'wtf', 'wait','waiting', 'epicfail', 'dump',
                     'mechanical','anyway','terrify','terrifi','storm' ,'really wish'))
#pointless remove
max(pos.words %in% 'peaceful')
max(neg.words %in% 'resign')

sc = laply(sentences, function(sentence, pos.words, neg.words) {
  
  # split into words. str_split is in the stringr package
  word.list = str_split(sentence, '\\s+')
  # sometimes a list() is one level of hierarchy too much
  words = unlist(word.list)
  
  # compare our words to the dictionaries of positive & negative terms
  pos.matches = match(words, pos.words)
  neg.matches = match(words, neg.words)
  
  # match() returns the position of the matched term or NA
  # we just want a TRUE/FALSE:
  pos.matches = !is.na(pos.matches)
  neg.matches = !is.na(neg.matches)
  
  # and conveniently enough, TRUE/FALSE will be treated as 1/0 by sum():
  score= list(sum(pos.matches),sum(neg.matches))
  
  return(score)
}, pos.words, neg.words, .progress="none" )


sc<-data.frame(sc)
names(sc)<-c("pos_words","neg_words")



#####################
###word stem
####################
sentences<-stem_text(sentences)


wordss<-
  data.frame(str_count(sentences , "about"),
             str_count(sentences , "again"),
             str_count(sentences , "all"),
             str_count(sentences , "amp"),
             str_count(sentences , "any"),
             str_count(sentences , "aw"),
             str_count(sentences , "back"),
             str_count(sentences , "can"),
             str_count(sentences , "cant"),
             str_count(sentences , "catch"),
             str_count(sentences , "come"),
             str_count(sentences , "day"),
             str_count(sentences , "dont"),
             str_count(sentences , "drive"),
             str_count(sentences , "enough"),
             str_count(sentences , "feel"),
             str_count(sentences , "get"),
             str_count(sentences , "goo"),
             str_count(sentences , "googl"),
             str_count(sentences , "got"),
             str_count(sentences , "ha"),
             str_count(sentences , "home"),
             str_count(sentences , "hope"),
             str_count(sentences , "http"),
             str_count(sentences , "just"),
             str_count(sentences , "know"),
             str_count(sentences , "last"),
             str_count(sentences , "late"),
             str_count(sentences , "like"),
             str_count(sentences , "lol"),
             str_count(sentences , "look"),
             str_count(sentences , "love"),
             str_count(sentences , "make"),
             str_count(sentences , "miss"),
             str_count(sentences , "much"),
             str_count(sentences , "need"),
             str_count(sentences , "new"),
             str_count(sentences , "night"),
             str_count(sentences , "now"), 
             str_count(sentences , "off"),
             str_count(sentences , c("omg","god") ),
             str_count(sentences , "one"),
             str_count(sentences , "realli"),
             str_count(sentences , "rec"),
             str_count(sentences , "see"),
             str_count(sentences , "so"),
             str_count(sentences , "still"),
             str_count(sentences , c("thank","thx")),
             str_count(sentences , "think"),
             str_count(sentences , "though"),
             str_count(sentences , "time"),
             str_count(sentences , "today"),
             str_count(sentences , "tomorrow"),
             str_count(sentences , "twitter"),
             str_count(sentences , "user"),
             str_count(sentences , "want"),
             str_count(sentences , "watch"),
             str_count(sentences , "well"),
             str_count(sentences , "why"),
             str_count(sentences , "will"),
             str_count(sentences , "wish"),
             str_count(sentences , "work"),
             str_count(sentences , c("suppose","guess") ),
             str_count(sentences , c("isnt","dont","arent") ),
             str_count(sentences , c("any more","no longer","no more") )
             
  )
#never what told
names(wordss)<-c("about","again", "all","amp", "any","aw",
                 "back","can","cant","catch",
                 "come",
                 "day",
                 "dont",
                 "drive",
                 "enough",
                 "feel",
                 "get",
                 "goo",
                 "googl",
                 "got",
                 "ha",
                 "home",
                 "hope",
                 "http",
                 "just",
                 "know",
                 "last",
                 "late",
                 "like",
                 "lol",
                 "look",
                 "love",
                 "make",
                 "miss",
                 "much",
                 "need",
                 "new",
                 "night",
                 "now", 
                 "off",
                 "omg",
                 "one",
                 "realli",
                 "rec",
                 "see",
                 "so",
                 "still",
                 "thank",
                 "think",
                 "though",
                 "time",
                 "today",
                 "tomorrow",
                 "twitter",
                 "user",
                 "want",
                 "watch",
                 "well",
                 "why",
                 "will",
                 "wish",
                 "work",
                 "suppose","isnt","nomore")



mat<-cbind(sc,puntc,wordss)



mat[] <- lapply(mat, as.numeric) 


cat( paste( names(mat), collapse='\n' ) )


X<-as.matrix( mat )


dim(X)

train_ind <- rbinom(nrow(text),1, 0.7)





Xt<-data.matrix( X[train_ind==1,]  ) 

yt<-as.numeric(y[train_ind==1])
xgb <- xgboost(data =Xt, 
               label = yt, 
               seed=1, 
               nround=20, 
               max_depth=10,
               subsample = 0.4,  
               Gamma =2,
               lambda =2,
               min_child_weight=6,
               objective = "binary:logistic" ,
               eval_metric="auc"
)
 #y_boost <- predict(xgb, Xt)
 #auc(yt, y_boost)

Xv<-data.matrix( X[train_ind==0,]  ) 
yv<-as.numeric(y[train_ind==0])
yv_boost <- predict(xgb, Xv)
auc(yv, yv_boost)

saveRDS(xgb, "xgb_tw.rds")
#0.7895

write.csv(cbind(yt,Xt), file = "train.csv",row.names=FALSE, na="")
write.csv(cbind(yv,Xv), file = "test.csv",row.names=FALSE, na="")

dim(mat[train_ind==0,c(1,2)])
dim(Xv)
length(yv)
dim(mat[train_ind==0,c(1,2)] )
length(text$content[train_ind==0])
 
out2<-cbind(yv,yv_boost,mat[train_ind==0,c(1,2)],text$content[train_ind==0])
write.csv(out2, file = "DBtest.csv",row.names=FALSE, na="")


depvar=yv
predcol=yv_boost
groups=10
 

helper = data.frame(cbind(depvar, predcol))
helper[,"bucket"] = ntile(-1*helper[,"predcol"], groups)
gaintable = helper %>% group_by(bucket)  %>%
  summarise_at(vars(depvar), funs(total = n(),
                                  totalresp=sum(., na.rm = TRUE))) 

gaintable<-data.frame(gaintable)
gaintable$rate=gaintable[,3]/gaintable[,2]
gaintable

sum(gaintable[,3])/sum(gaintable[,2])

require.package("pROC")
auc(depvar, predcol)


mislabel<-which( (yv_boost<0.1) & yv==1)


sen.v<-text[train_ind==0,] 
sent.v<-sentences[train_ind==0] 

is<-10
sen.v[mislabel[is],]
Xv[mislabel[is],] 
sent.v[mislabel[is]]


############################
########scoring############
###########################

require.package("twitteR")
require.package("ROAuth") 
require.package("ggplot2")
require.package("httpuv")
require.package("RColorBrewer")
require.package("wordcloud2")
require.package("tau")


api_key <- "6yPexcgVAAgY8xJBkN1AjN9FS"
api_secret <- "hFgGgzMvz37ljHs7dS9cnYmATGV8rQu5FpjOUPZNxuwmFqtLFj"
access_token <- "20852416-5tX8VVTSFVTLJzjvz3Cn6CEme6F6ePznk2sLgHY7C"
access_token_secret <- "IEJkknREhOCs3vRMSVWAcSvlLcKBWSATjh39v6hK0qe7m"

setup_twitter_oauth(api_key, api_secret, access_token, access_token_secret)
#setup_twitter_oauth("6yPexcgVAAgY8xJBkN1AjN9FS", "hFgGgzMvz37ljHs7dS9cnYmATGV8rQu5FpjOUPZNxuwmFqtLFj")

search.string <- "cvs"
no.of.tweets <- 5000

strt_dt='2017-02-10'
end_dt='2017-02-16'


tweets.list <- searchTwitter(search.string, n=no.of.tweets,lang="en",since=strt_dt,until=end_dt)
tweets.df<-twListToDF(tweets.list)


#write.csv(tweets.df,file="cvstweets0124.csv",row.names=F)

head(tweets.df)
DatasetCVS<-read.csv("cvstweets0124.csv")
sentences<-DatasetCVS$text 
head(sentences)

#score with model
xgb_so<-readRDS("xgb_tw.rds")
X.sentiment <- predict(xgb, X)
 
job.1<-grepl( 'job' , sentences )| grepl( 'hire' , sentences )
#intern opening
competitors.1<-
  grepl( 'walgreen' , sentences )| grepl( 'amazon' , sentences )|
  grepl( 'walmart' , sentences )|grepl( 'riteaid' , sentences )
coupon.1<-grepl('coupon', sentences ) #sale

twit.categories<-rep('others',length(sentences))
twit.categories[job.1]<-'job'
twit.categories[competitors.1]<-'competitors'
twit.categories[coupon.1]<-'coupon'

twit.rt<-grepl( 'RT @' , DatasetCVS$text )
table(twit.rt)

twit.https<-grepl( 'https' , sentences )
table(twit.https)


freq_table(twit.categories)



sentences<-sapply(sentences,function(row) iconv(row, "latin1", "ASCII", sub=""))
sentences<-tolower(sentences)

length(DatasetCVS$text)
length(sentences)

names(DatasetCVS$text)

out<-cbind(X.sentiment, twit.categories,mat$pos_words,mat$neg_words,
      DatasetCVS$text,sentences )

head(out[,6])

write.csv(out,file="cvstweets0124score.csv",row.names=T)

X.sentiment[1:10]
DatasetCVS$text[ 10]


rm_words <- readLines(system.file("stopwords", "english.dat",package = "tm"))
rm_words <- c(rm_words,"cvs","rt",'can','just','amp','want')
              #"healthcare","pharmacy","health","walgreens" 

redsent1<- trimws(remove_stopwords(sentences, rm_words,lines=TRUE))

splitsent=as.list((str_split(tolower(redsent1),'\\s+')))
wordfreq<-as.data.frame(table(unlist(splitsent)))
wordfreq1<-filter(wordfreq,Freq>10)
#wordfreq[wordfreq$Freq<=10,] 
#some sentimental words"bad awesome awful" were removed


wordcloud2(wordfreq1)

head(DatasetCVS$text[twit.categories=='others'])


#I registered online. I was told 25 minutes. I checked in 5 minutes before my appointment and now it's been an hour. What is the purpose of the online system?!
#I can't see me prescriptions to refill. Kind of makes the app pointless! Removing from my phone!
#It's not user friendly any more
#I keep trying to log in but it wont let me reset a new one. ???

#---pos
#It worked well 
#Still getting used to it but I like it

