library(RODBC)
rm(list = ls())

## this code pull the data for past 14 days
## if you want to use a different timeframe, please change them in line 20, 34 and 68

## connect to Teradata
Sys.setenv(ODBCINI = "/opt/teradata/client/ODBC_64/odbc.ini")
Sys.setenv(PATH = "/opt/teradata/client/16.00/bin:/usr/local/sbin:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.131-3.b12.el7_3.x86_64/bin:/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/bin:/opt/teradata/client/ODBC_64:/usr/local/bin")
driver='/opt/teradata/client/ODBC_64/lib/tdata.so'
user='cea_user'
password='makem0ney4cvs'
channel<-odbcConnect("testpbm",uid= user,pwd=password) 

## pull PeopleSafe data
YZ_CALL_TEST=paste0("Create Multiset Table DSS_CEA2.YZ_CALL_TEST as (
                select   UNQ_CALL_ID,ACTVY_CD,a.QL_BNFCY_ID as FMLY_BNFCY_ID, CRTE_TS as CALL_TS,PREV_CALL_IND, ACTVY_SPEED_CD, CALL_TYP_CD,SBSCR_ACCT_ID
                 from dwu_edw.V_CC_PSV_CALL_DATA a
                 inner join DSS_CEA2.YZ_BNFCY_FMLY b on a.QL_BNFCY_ID=b.QL_BNFCY_ID
                 where CRTE_TS(date) between date-14 and date-1
                 and cntct_src_cd = '0001' and cntct_form_cd = '0001' and cntct_mode_cd = '0003'
)With Data Primary Index (UNQ_CALL_ID)" )
YZ_CALL_TEST=gsub("[\r\n]", " ", YZ_CALL_TEST)
sqlQuery(channel, YZ_CALL_TEST)

## pull ECCR data
YZ_WEB_TEST=paste0("Create Multiset Table DSS_CEA2.YZ_WEB_TEST as (
select   SEG_TYP_DESC,c.LVL1_ACCT_NM,c.LVL1_ACCT_ID,INTRCTN_KEY_ID, CRTE_TS as WEB_TS, SYS_ID, INTRCTN_TYP_CD,INTRCTN_RSLT_CD,b.QL_BNFCY_ID,b.SBSCR_ACCT_ID
from dwu_edw.V_ECCA_INTRCTN a
inner join DSS_CEA2.YZ_BNFCY_FMLY b on a.ECCA_MBR_ID=b.QL_BNFCY_ID
inner join DWU_EDW.V_MBR_ACCT_DENORM dd on dd.MBR_ACCT_GID=a.MBR_ACCT_GID
inner join DWU_EDW.V_CLNT_ACCT_DENORM c on c.LVL3_ACCT_GID=dd.LVL3_ACCT_GID
left join BOB_APP.V_CLNT_DTL e on e.LVL3_ACCT_GID=c.LVL3_ACCT_GID
where CRTE_DT(date) between date-14 and date-1
and SYS_ID in ('PORTAL','POR_MOB','POR_TAB','POR_IOSAP','POR_ANDAP','ICM','ICM_MOB','ICM_TAB','ICM_IOSAP','ICM_ANDAP')
)With Data Primary Index (INTRCTN_KEY_ID)" )
YZ_WEB_TEST=gsub("[\r\n]", " ", YZ_WEB_TEST)
sqlQuery(channel, YZ_WEB_TEST)

## remove all session start and session end records
deletesql=paste0("Delete from DSS_CEA2.YZ_WEB_TEST where INTRCTN_TYP_CD = '3080' or INTRCTN_TYP_CD = '3081'" )
sqlQuery(channel, deletesql)

## join call and web data together, only extract the call within 2 hours
YZ_PBM_CALL_TABLEAU_TEMP=paste0("Create Multiset Table DSS_CEA2.YZ_PBM_CALL_TABLEAU_TEMP as (
select UNQ_CALL_ID,ACTVY_CD,FMLY_BNFCY_ID, CALL_TS,PREV_CALL_IND, ACTVY_SPEED_CD, CALL_TYP_CD,
b.*,
(CALL_TS-WEB_TS) DAY(4) TO SECOND as difference,
case when CALL_TS(date) between date'2018-03-11' and date'2018-11-03' then 
(extract (day from difference)*86400 + extract (hour from difference)*3600 
+ extract (minute from difference)*60 + extract (second from difference) - 7200) / 60 
when CALL_TS(date) between date'2019-03-10' and date'2019-11-02' then 
(extract (day from difference)*86400 + extract (hour from difference)*3600 
+ extract (minute from difference)*60 + extract (second from difference) - 7200) / 60
else
(extract (day from difference)*86400 + extract (hour from difference)*3600 
+ extract (minute from difference)*60 + extract (second from difference) - 3600) / 60 
end as diff
from DSS_CEA2.YZ_CALL_TEST a
inner join DSS_CEA2.YZ_WEB_TEST b
on a.SBSCR_ACCT_ID = b.SBSCR_ACCT_ID
where diff between 0 and 120
)With Data Primary Index (UNQ_CALL_ID,INTRCTN_KEY_ID)" )
YZ_PBM_CALL_TABLEAU_TEMP=gsub("[\r\n]", " ", YZ_PBM_CALL_TABLEAU_TEMP)
sqlQuery(channel, YZ_PBM_CALL_TABLEAU_TEMP)

## remove any duplicate dates
deletesql=paste0("Delete from DSS_CEA2.YZ_PBM_CALL_TABLEAU where CALL_TS(date) between date-14 and date-1" )
sqlQuery(channel, deletesql)

## insert to the main table
insertsql=paste0("insert into dss_cea2.YZ_PBM_CALL_TABLEAU select * from dss_cea2.YZ_PBM_CALL_TABLEAU_TEMP" )
sqlQuery(channel, insertsql)

## drop all the temp tables
dropsql=paste0("drop table dss_cea2.YZ_PBM_CALL_TABLEAU_TEMP" )
sqlQuery(channel, dropsql)
dropsql=paste0("drop table dss_cea2.YZ_CALL_TEST" )
sqlQuery(channel, dropsql)
dropsql=paste0("drop table dss_cea2.YZ_WEB_TEST" )
sqlQuery(channel, dropsql)

close(channel)