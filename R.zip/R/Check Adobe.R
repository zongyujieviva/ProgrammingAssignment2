SCAuth("yzong:CVS Health","ba9be9678ba82cfad06913cab927ef1e",company="CVS Health")

calc<- GetSegments("cvshealthretailprod")

calc2<- GetMetrics("cvshealthretailprod")

calc3<- GetElements("cvshealthretailprod")

write.csv(FinalOutput,"/home/yzong/Geoff.csv")

