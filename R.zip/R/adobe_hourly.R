library ("httr")
library ("RSiteCatalyst")
library ("base64enc")
library ("jsonlite")
library ("plyr")
library ("stringi")
library ("curl")
library ("xml2")
library ("RCurl")
library ("openssl")

rm(list = ls())
setwd("/home/ronxu/apipulldata")

lp=7


# Adobe for ICE CVS

dt <- Sys.Date()

print(dt)
dtl <- dt-lp

SCAuth("yzong:CVS Health","ba9be9678ba82cfad06913cab927ef1e",company="CVS Health")

cdt=dt-40
cleandata <- QueueTrended("cvshealthretailprod",
                          cdt-lp,
                          cdt,
                            c("cm300002782_5955531db0178542762f5a06","cm300002782_5955565c21d4774a60bbb0cb","cm300002782_59555866bef0d35640aa5f23",
                              "cm300002782_59c13f8121d4772cfd008744","cm300002782_59f78856f118f070b78066d4","cm300002782_59f788897f0bfd2127b0da51"),
                            c("eVar41"),
                            segment.id = "s300002782_599c7c0217a0459e6c5e9b8d",start=1,date.granularity = "day"
)


orders.data <- QueueTrended("cvshealthretailprod",
                            dt-lp,
                            dt,
                            c("cm300002782_5955531db0178542762f5a06","cm300002782_5955565c21d4774a60bbb0cb","cm300002782_59555866bef0d35640aa5f23",
                              "cm300002782_59c13f8121d4772cfd008744","cm300002782_59f78856f118f070b78066d4","cm300002782_59f788897f0bfd2127b0da51",
                              "event52", "event53",
                              "cm300002782_58c9b34db0178575bff014ba" , "cm300002782_58c9b3e0f73f230cb9bf9f98" ),
                            c("eVar41"),
                            segment.id =  "s300002782_599c7c0217a0459e6c5e9b8d" ,start=1,date.granularity = "hour"
)
orders.data<-orders.data[ orders.data$name %in% c('dweb','mweb','tweb','mapp'),]


orders.data2 <- QueueTrended("cvshealthretailprod",
                            dt-lp,
                            dt,
                            c("cm300002782_5955531db0178542762f5a06","cm300002782_5955565c21d4774a60bbb0cb","cm300002782_59555866bef0d35640aa5f23",
                              "cm300002782_59c13f8121d4772cfd008744","cm300002782_59f78856f118f070b78066d4","cm300002782_59f788897f0bfd2127b0da51",
                              "event52", "event53",
                              "cm300002782_58c9b34db0178575bff014ba" , "cm300002782_58c9b3e0f73f230cb9bf9f98" ),
                            c("eVar41"),
                            segment.id = c("s300002782_599c7c0217a0459e6c5e9b8d","s300002782_58b7287ce4b0995d31eda559"),start=1,date.granularity = "hour"
)
orders.data2<-orders.data2[ orders.data2$name %in% c('dweb','mweb','tweb','mapp'),]

orders.data3 <- QueueTrended("cvshealthretailprod",
                             dt-lp,
                             dt,
                             c("cm300002782_5955531db0178542762f5a06","cm300002782_5955565c21d4774a60bbb0cb","cm300002782_59555866bef0d35640aa5f23",
                               "cm300002782_59c13f8121d4772cfd008744","cm300002782_59f78856f118f070b78066d4","cm300002782_59f788897f0bfd2127b0da51",
                               "event52", "event53",
                               "cm300002782_58c9b34db0178575bff014ba" , "cm300002782_58c9b3e0f73f230cb9bf9f98" ),
                             c("eVar41"),
                             segment.id ="",start=1,date.granularity = "hour")
orders.data3<-orders.data3[ orders.data3$name %in% c('dweb','mweb','tweb','mapp'),]

orders.data$date <- as.Date(orders.data$datetime)
ICE.CVS <- orders.data[ , !(names(orders.data) %in% c("datetime","url","segment.id","segment.name"))]
ICE.CVS$BU <- "CVS"
colnames(ICE.CVS)=c("HR","PLATFORM","Auth_Login","Order_Review","Order_Confirm","RX_RTL","RX_PBM","RX_SPL",'Auth_Start','Auth_Complete'  ,  'Login_Start','Login_Complete'  ,"DT","BU")

ICE.CVS$Auth_Login <- orders.data2$cm300002782_5955531db0178542762f5a06
ICE.CVS$Auth_Start <- orders.data3$event52
ICE.CVS$Auth_Complete <- orders.data3$event53

   


print("ICE.CVS Hr:")
print(table(ICE.CVS[ICE.CVS$DT==dt & ICE.CVS$Auth_Login>0, "HR"]))
print("ICE.CVS DT:")
print(table( ICE.CVS$DT ))

dtt= unique(format(ICE.CVS$DT[!is.na(ICE.CVS$DT)], "%Y-%m-%d"))

# Adobe for Specialty

SCAuth("yzong:CVS Health","ba9be9678ba82cfad06913cab927ef1e",company="CVS Health")

 
orders.data <- QueueTrended("cvshealthspecialtyprod",
                            dt-lp,
                            dt,
                            c("cm300002782_58c9b1d8b0178575bff014b8","checkouts","orders",
                              "units","cm300002782_58dd33233f1e92295434779b", "event9",
                              "cm300002782_58c9b34db0178575bff014ba" , "cm300002782_58c9b3e0f73f230cb9bf9f98" ),
                            c("eVar41"),
                            segment.id = "s300002782_58d57897e4b0c4e59155a0a6",start=1,date.granularity = "hour"
)

orders.data$date <- as.Date(orders.data$datetime)
SPL <- orders.data[ , !(names(orders.data) %in% c("datetime","url","segment.id","segment.name"))]

SPL$RX_RTL <- 0
SPL$RX_PBM <- 0
SPL$BU <- "SPL"

colnames(SPL)=c("HR","PLATFORM","Auth_Login","Order_Review","Order_Confirm","RX_SPL",'Auth_Start','Auth_Complete' ,  'Login_Start','Login_Complete' ,"DT","RX_RTL","RX_PBM","BU")

# Combine data:

finalcvs <- rbind.fill(ICE.CVS,SPL)
finalcvs$ID <- seq.int(nrow(finalcvs))
finalcvs <- finalcvs[,c(15,14,13,1,2,3,4,5,6,7,8,9,10,11,12)]


#####################
# Define 24 hours
#####################

cdtt=paste0("date'",dtt,"'")
dcdtt=paste(cdtt,",", collapse="")
dcdttc=substr(dcdtt,1,nchar(dcdtt)-1)


#####################
# Loading the RODBC Package
#####################
library(RODBC)

Sys.setenv(ODBCINI = "/opt/teradata/client/ODBC_64/odbc.ini")

Sys.setenv(PATH = "/opt/teradata/client/16.00/bin:/usr/local/sbin:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.131-3.b12.el7_3.x86_64/bin:/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/bin:/opt/teradata/client/ODBC_64:/usr/local/bin")

driver='/opt/teradata/client/ODBC_64/lib/tdata.so'
user='cea_user'
password='makem0ney4cvs'
channel<-odbcConnect("testpbm",uid= user,pwd=password) 
 


####################
# Delete 24 hours
####################
deletesql1=paste0("Delete from DSS_CEA2.YZ_ALL_MTS_HOUR where PLATFORM='mapp'  and BU='ICE CMK' and dt in (", dcdttc,  ")" )
sqlQuery(channel, deletesql1)
deletesql2=paste0("Delete from DSS_CEA2.YZ_ALL_MTS_HOUR where BU='CVS' and dt in (", dcdttc,  ")" )
sqlQuery(channel, deletesql2)
deletesql3=paste0("Delete from DSS_CEA2.YZ_ALL_MTS_HOUR where BU='SPL' and dt in (", dcdttc,  ")" )
sqlQuery(channel, deletesql3)

#####################
# Write to teradata table(s)
#####################
sqlSave(channel, finalcvs , tablename = "DSS_CEA2.YZ_ALL_MTS_HOUR",rownames=FALSE, append=TRUE,fast = T,verbose=T)

close(channel)