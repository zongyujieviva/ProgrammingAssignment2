library ("dplyr")
library ("sqldf")
library ("RSiteCatalyst")
library(data.table)
library(openxlsx)
library(reshape2)
library(rpart)
library(AppliedPredictiveModeling)
library(caret)
library(forecast)
rm(list = ls())
dtt <- as.Date("2018-09-16")
dtt2<- as.Date("2018-12-29")
wk <- week(dtt)

setwd("/home/yzong/Forecast")

wb<-loadWorkbook("Forecast_Raw.xlsx") 

traffic <- read.xlsx(wb, sheet = "Traffic", startRow = 1, colNames = TRUE,
          rowNames = FALSE, detectDates = TRUE, skipEmptyRows = TRUE,
          skipEmptyCols = TRUE)
orders <- read.xlsx(wb, sheet = "Order", startRow = 1, colNames = TRUE,
                     rowNames = FALSE, detectDates = TRUE, skipEmptyRows = TRUE,
                     skipEmptyCols = TRUE)
email <- read.xlsx(wb, sheet = "Email", startRow = 1, colNames = TRUE,
                     rowNames = FALSE, detectDates = FALSE, skipEmptyRows = TRUE,
                     skipEmptyCols = TRUE)

deal <- read.xlsx(wb, sheet = "Deal", startRow = 1, colNames = TRUE,
                     rowNames = FALSE, detectDates = FALSE, skipEmptyRows = TRUE,
                     skipEmptyCols = TRUE)

email$DT <- as.Date(email$DT,origin = "1899-12-30")
deal$DT <- as.Date(deal$DT,origin = "1899-12-30")
email <- email[email$DT<=dtt2,]
email$week <- weekdays(email$DT)
email_t1 <- dcast(email, DT ~ Email_Campaigns, fun.aggregate = sum, value.var="Volume")
email_t2 <- dcast(email, DT ~ Email_Groups, fun.aggregate = sum, value.var="Volume")
f <- function(x) as.integer(length(x) > 0)
email_t3 <- dcast(email, DT ~ week,fun.aggregate = f)
email_t <- left_join(email_t3,email_t2,by=c("DT")) %>% left_join(.,email_t1, by=c("DT"))

test <- left_join(traffic, email_t, by= c("DT")) %>% left_join(.,deal, by=c("DT"))
test <- test[test$DT<=dtt2,]
test[is.na(test)] <- 0

training <- test[test$DT<=dtt,]
testing <- test[which(test$DT>dtt & test$DT<=dtt+42),]
validation <-test[which(test$DT>dtt+42 & test$DT<=dtt+84),]
training <- training[,-c(1)]
testing <- testing[,-c(1)]
validation <- validation[,-c(1)]

F1 <- train(COM_Traffic ~ ., method = "rf", data = training)
F2 <- train(COM_Traffic ~ ., method = "leapSeq", data = training)
F3 <- train(COM_Traffic ~ ., method = "gbm", data = training,verbose=FALSE)

coef(F2$finalModel, F2$bestTune$nvmax)

qplot(predict(F2,testing),COM_Traffic,data=testing)

tsl <- ts(test$COM_Traffic,frequency = 7)
tslTrain <- window(tsl,start=1,end=wk)
tslTest <- window(tsl,start=wk,end=(wk+6-0.01))
etsl <- ets(tslTrain,model="ZZZ")
fcast <-forecast(etsl,h=42)
## plot(fcast);lines(tslTest,col="red");lines(etsl$fitted,col='orange')

plot(decompose(tsl))

## predDF <- data.frame(pred1=predict(F1,testing),pred2=predict(F2,testing),fcast,COM_Traffic=testing$COM_Traffic)
predDF <- data.frame(pred1=predict(F1,testing),pred2=predict(F2,testing),pred3=predict(F3,testing),fcast,COM_Traffic=testing$COM_Traffic)
predDF <- predDF[,-c(5:8)]
combModFit <- train(COM_Traffic ~.,methods="gam",data=predDF)
combPred <- predict(combModFit,predDF)
## final_ <- data.frame(testing$COM_Traffic,combPred)

tslTrain <- window(tsl,start=1,end=wk+6)
tslTest <- window(tsl,start=wk+6,end=(wk+12-0.01))
etsl <- ets(tslTrain,model="ZZZ")
fcast2 <-forecast(etsl,h=42)
fcast3 <-data.frame(fcast2)[c(1:42),1]

## predVDF <- data.frame(pred1=predict(F1,validation),pred2=predict(F2,validation),Point.Forecast=fcast3)
predVDF <- data.frame(pred1=predict(F1,validation),pred2=predict(F2,validation),pred3=predict(F3,validation),Point.Forecast=fcast3)
combPredV <- predict(combModFit,predVDF)
predict(combModFit$finalModel, predVDF, interval = "confidence")

final <- data.frame(validation$COM_Traffic,combPredV,predict(F1,validation),predict(F2,validation),predict(F3,validation),fcast3)

## orders

test2 <- left_join(orders, email_t, by= c("DT")) %>% left_join(.,deal, by=c("DT"))
test2 <- test2[test2$DT<=dtt2,]
test2[is.na(test2)] <- 0

training <- test2[test2$DT<=dtt,]
testing <- test2[which(test2$DT>dtt & test2$DT<=dtt+42),]
validation <-test2[which(test2$DT>dtt+42 & test2$DT<=dtt+84),]
training <- training[,-c(1)]
testing <- testing[,-c(1)]
validation <- validation[,-c(1)]

F1 <- train(Orders ~ ., method = "rf", data = training)
F2 <- train(Orders ~ Orders_LY+Sunday+Monday+Tuesday+Wednesday+Thursday+Friday+Holidays+High+Medium+FSNM, method = "leapSeq", data = training)
F3 <- train(Orders ~ ., method = "gbm", data = training,verbose=FALSE)
coef(F2$finalModel, F2$bestTune$nvmax)

tsl <- ts(test2$Orders,frequency = 7)
tslTrain <- window(tsl,start=1,end=wk)
tslTest <- window(tsl,start=wk,end=(wk+6-0.01))
etsl <- ets(tslTrain,model="MMM")
fcast <-forecast(etsl,h=42)
## plot(fcast);lines(tslTest,col="red");lines(etsl$fitted,col='orange')

predDF <- data.frame(pred1=predict(F1,testing),pred2=predict(F2,testing),pred3=predict(F3,testing),Orders=testing$Orders)
##predDF <- predDF[,-c(5:8)]
combModFit <- train(Orders ~.,methods="gam",data=predDF)
combPred <- predict(combModFit,predDF)

tslTrain <- window(tsl,start=1,end=wk+6)
tslTest <- window(tsl,start=wk+6,end=(wk+12-0.01))
etsl <- ets(tslTrain,model="ZZZ")
fcast2 <-forecast(etsl,h=42)
fcast3 <-data.frame(fcast2)[c(1:42),1]

predVDF <- data.frame(pred1=predict(F1,validation),pred2=predict(F2,validation),pred3=predict(F3,validation))
combPredV <- predict(combModFit,predVDF)

final2 <- data.frame(validation$Orders,combPredV,predict(F1,validation),predict(F2,validation),predict(F3,validation))
