#########################
##load ODBC package#####
########################
require.package<-function(pckg)
{
  package.installed<-try(require(pckg, character.only =TRUE))
  if (!package.installed) {
    cat(paste("Installing", pckg,  "from CRAN\n", sep=" "))
    install.packages(pckg )
    require(pckg, character.only =TRUE)
  }#if
}#require.package

 
require.package("curl")
require.package("RCurl")
require.package("openssl")
require.package ("httr")
require.package("jsonlite")
require.package("xml2")
require.package("plyr")

require.package("tau")
require.package("XML")
require.package("stringr")
require.package("pROC")
require.package("RTextTools")
require.package("e1071")
require.package("xgboost")
require.package("parallel")
require.package("syuzhet")
require.package("rJava")
require.package("openNLP")
require.package("NLP")
require.package("openxlsx") 

require.package("scales")

require.package("xgboost")
require.package("lubridate")
require.package("data.table")
require.package("dummy")

wd="/home/ronxu/nlp"

setwd(wd)


st_dt<-'2017-06-20'
ed_dt<-'2017-06-30'
domai<-"www.caremark.com"

start_dt='2017-06-26'
end_dt='2017-06-30'

# www.caremark.com
# unenroll.autorefill.caremark.com
# ios.caremark.com
# ge-invite.www.caremark.com
# android.caremark.com
# www.cvsspecialty.com
# omail.caremark.com
# registration.caremark.com
# ice-ouput.caremark.com
# client.caremark.com


# url_p1<-"https://webservice.opinionlab.com/display/?start_date="
# url_p2<-"&end_date="
# url_p3<-"&type=domain&realm="
# url_p4<-"&xml_style=0"
# url2<-paste0(url_p1,st_dt,url_p2,ed_dt,url_p3,domai,url_p4)
# print(url2)
#  
# a<-GET(url2, authenticate("webservice@caremark.com", "Aug-2017"))
#  
# ar<-read_xml(httr::content(a, "raw")) 
# comments<-trimws(xml_text(xml_find_all(ar, paste0("//","comments"))))


pullxml<-function(domai,st_dt,ed_dt){
  url_p1<-"https://webservice.opinionlab.com/display/?start_date="
  url_p2<-"&end_date="
  url_p3<-"&type=domain&realm="
  url_p4<-"&xml_style=0"
  url2<-paste0(url_p1,st_dt,url_p2,ed_dt,url_p3,domai,url_p4)
  print(url2)
  # a<-ifelse( grepl('caremark.com|specialty.com',domai) ,
  #GET(url2, authenticate("webservice@caremark.com", "Jan-2017")) 
  #,
  a<-GET(url2, authenticate("webservice@caremark.com", "Aug-2017"))
  #)
  ar<-read_xml(httr::content(a, "raw")) 
  
  comments<-trimws(xml_text(xml_find_all(ar, paste0("//","comments"))))
  if( !identical(comments, character(0)) ){
    df<-data.frame(
      trimws(xml_text(xml_find_all(ar, paste0("//","submission_date")))),
      comments,
      trimws(xml_text(xml_find_all(ar, paste0("//","categories")))),
      trimws(xml_text(xml_find_all(ar, paste0("//","os_type")))),
      trimws(xml_text(xml_find_all(ar, paste0("//","overall_rating")))),
      trimws(xml_text(xml_find_all(ar, paste0("//","content_rating")))),
      trimws(xml_text(xml_find_all(ar, paste0("//","design_rating")))),
      trimws(xml_text(xml_find_all(ar, paste0("//","browser_type")))),
      trimws(xml_text(xml_find_all(ar, paste0("//","usability_rating")))),
      trimws(xml_text(xml_find_all(ar, paste0("//","time_on_page")))),
      trimws(xml_text(xml_find_all(ar, paste0("//","url")))),domai 
    )
    return(df)
  }
  
}

 



text.df0<- pullxml('www.caremark.com',start_dt,end_dt)

text.df0<- pullxml('android.caremark.com',start_dt,end_dt)

text.df=text.df0
names(text.df)<-c("sub_date",'comments', 'caegories', 'os_type',
                  'overall_ratings','content_rating',
                  'design_rating', 'browser_type', 'usability_rating', 
                  'time_on_page' ,'url','domai')
text.df$comments <-as.character( text.df$comments )
text.df<-text.df[  nchar(text.df$comments)>1,  ]

 



text.df$theme_url<-gsub('%20',' ',gsub('https%3A//www.caremark.com/', '',text.df$url) )




write.xlsx(text.df, file = "caremark_oppionlab2.xlsx", colNames = TRUE, 
           sheetName='android.caremark.com')
