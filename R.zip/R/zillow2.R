train<-merge(train0,prop,all.x=T)

train[ ,nmiss := rowSums(is.na(.SD) ), .SDcols = 4:ncol(train)]

train[,tmonth:=month(transactiondate)]

train[ , log_left:=calculatedfinishedsquarefeet/lotsizesquarefeet]
train[is.na(log_left), log_left:=-9]
train<-merge(train,zipzon,by=c('regionidzip','propertyzoningdesc'),all.x=T)
train[is.na(garagetotalsqft),garagetotalsqft:=-99 ]
lancode<-train[, list(  lancode_melevel=mean( round(  logerror ,3 ))
) ,
propertycountylandusecode ]
train<-merge(train,lancode,by= 'propertycountylandusecode',all.x=T)

zippro<-train[, list(maxerror_zplevel=max( round(  logerror ,3 )) 
) ,
list(regionidzip,propertycountylandusecode)]
train<-merge(train,zippro,by= c('regionidzip','propertycountylandusecode'),all.x=T)

citypro<-train[, list(meaerror_cplevel=mean( round(  logerror ,3 )) 
) ,
list(regionidcity,propertycountylandusecode)]
train<-merge(train,citypro,by= c('regionidcity','propertycountylandusecode'),all.x=T)



lel3<-c('meaerror_level',
        'maxerror_zplevel' ,
        'lancode_melevel',  'meaerror_cplevel' ,'log_left',
        'calculatedfinishedsquarefeet','taxamount' ,'nmiss'
        )

smp_size <- floor(0.85  * nrow(train))
train_ind <- sample(seq_len(nrow(train)), size = smp_size)

zXt<-as.matrix( train[train_ind,lel3,with=F] )
zXv<-as.matrix( train[-train_ind,lel3,with=F] )

zy<-as.numeric(train[,logerror ])
zyt<-as.numeric(zy[train_ind ])
zyv<-as.numeric(zy[-train_ind ]) 
mean(zyt);mean(zyv) 

xgb <- xgboost(data =zXt , 
               label = zyt , 
               seed=2, sample_type='weighted',
               eta=0.02 ,
               nround=500, 
               max_depth=2, 
               early_stopping_rounds = 10,
               
               objective = "reg:linear" ,
               eval_metric="mae"
)


zyv_boost <- predict(xgb, zXv)
#library(Metrics)
Metrics::mae(zyv_boost,zyv)

xgb.importance(lel3, model = xgb)
