library ("httr") 
library('data.table')

rm(list = ls())
setwd("/home/ronxu/Foresee")

Foresee_BU=readRDS('Foresee_BU.rds')
Forsee_primary_task=readRDS('Forsee_primary_task.rds')
BU_id=unique( Foresee_BU[Foresee_BU$active==T , 'BU_id'] )





pulldate=Sys.Date()-1


# DT=pulldate
#portalid=8842042
#portalid=BU_id[2]
#offi=0

##########################################
###function to pull one page of survey####
##########################################
CSATfunc.offset<-function( portalid,DT=pulldate,offi=offi){
  
  url = "https://api.foresee.com/v1/token"
  r <- httr::POST(url, add_headers( 
    authorization= "Basic RDgzcURwa3czcDNkUW1CcW5Kc2FDM0RneEpDbEx6dDI6RDRrMWt0ZlpSN21ERmtwcVZsT0I="
  ),
  query =list(scope="r_cx_basic",grant_type="client_credentials")
  )
  api_call_headers=paste0('Bearer ',content(r)$access_token)
  
  
  url4 =  paste0("https://api.foresee.com/v1/measures/", portalid ,"/data")  
  r2 <-  httr::GET(url4, add_headers( 
    Authorization= api_call_headers
  ) ,query =list(from=pulldate , to=DT , offset=offi   ) )
  it=content(r2)$items
  nreps=length(it)
  
  if(nreps>0){
    
    RDID=rep(NA,nreps)
    for( i in 1:nreps){
      RDID[i]=content(r2)$items[[i]]$id
    }
    
    
    CSAT=rep(NA,nreps)
    for( i in 1:nreps){
      ll=content(r2)$items[[i]]$latentScores
      lld <- lapply(ll, as.character)
      ll_ind=max( -99, which(sapply(lld, FUN=function(X)  "SATISFACTION"  %in% X))[1] , 
                  na.rm =T 
      )
      if(ll_ind==-99){ CSAT[i]='NA'  }else{
        CSAT[i]= unlist(ll[ll_ind][[1]]$score ) }
    }
    CSAT=as.numeric(CSAT)
    
    primary_task=rep(NA,nreps)
    for( i in 1:nreps){
      ll=content(r2)$items[[i]]$responses
      lld <- lapply(ll, as.character)
      ll_ind=max( -99, which(sapply(lld, FUN=function(X)  "Primary Task_2017"  %in% X))[1] ,
                  which(sapply(lld, FUN=function(X)  "Primary Task"  %in% X))[1]  , 
                  which(sapply(lld, FUN=function(X)  "Primary Reason"  %in% X))[1], 
                  which(sapply(lld, FUN=function(X)  "Primary reason"  %in% X))[1],
                  na.rm =T 
      )
      if(ll_ind==-99){ primary_task[i]='1000'  }else{
        primary_task[i] = as.numeric(ll[ll_ind][[1]]$answers )  }
      
    }    
    # which(sapply(lld, FUN=function(X)  "Primary reason Member"  %in% X))[1],
    # which(sapply(lld, FUN=function(X)  "Primary reason Shoppers"  %in% X))[1],
    
    
    Task_Accomplish=rep(NA,nreps)
    for( i in 1:nreps){
      ll=content(r2)$items[[i]]$responses
      lld <- lapply(ll, as.character)
      ll_ind=max( -99, which(sapply(lld, FUN=function(X)  "Task Accomplish"  %in% X))[1] ,
                  which(sapply(lld, FUN=function(X)  "Goal Accomplishment"  %in% X))[1] ,
                  which(sapply(lld, FUN=function(X)  "Task Completion"  %in% X))[1] ,
                  which(sapply(lld, FUN=function(X)  "Complete Task"  %in% X))[1] ,
                  which(sapply(lld, FUN=function(X)  "Task Accomplishment"  %in% X))[1] ,
                  na.rm =T 
      )
      if(ll_ind==-99){ Task_Accomplish[i]=0  }else{
        Task_Accomplish[i]=(ll[ll_ind][[1]]$answers=="1")*1  }
    } 
    
    
    os=rep(NA,nreps)
    for( i in 1:nreps){
      ll=content(r2)$items[[i]]$responses
      lld <- lapply(ll, as.character)
      ll_ind=max( -99, which(sapply(lld, FUN=function(X)  "os"  %in% X))[1] , 
                  na.rm =T 
      )
      if(ll_ind==-99){ os[i]='NA'  }else{
        os[i]= unlist(ll[ll_ind][[1]]$answers ) }
    } 
    os=sub("^([[:alpha:]]*).*", "\\1",  os)
    
    
    Navigation=rep(NA,nreps)
    for( i in 1:nreps){
      ll=content(r2)$items[[i]]$latentScores
      lld <- lapply(ll, as.character)
      ll_ind=max( -99, which(sapply(lld, FUN=function(X)  "Navigation"  %in% X))[1] , 
                  na.rm =T 
      )
      if(ll_ind==-99){ Navigation[i]='NA'  }else{
        Navigation[i]= unlist(ll[ll_ind][[1]]$score ) }
    }
    Navigation=as.numeric(Navigation)
    task_CSAT=data.table(RDID,primary_task,CSAT,Task_Accomplish,os,Navigation)
    
    hasMore=content(r2)$hasMore
  }else{
    hasMore=F
    task_CSAT=data.table(NA,NA,NA,NA,NA,NA)
    names(task_CSAT)=c('RDID', 'primary_task','CSAT','Task_Accomplish','os','Navigation')
  }
  
  return( list(hasMore, task_CSAT    ))
}

##########################################
###function to pull more pages of survey####
##########################################
CSATfunc<-function( portalid,DT=pulldate){
  
  offi=0
  repeat {
    if(offi==0){
      task_CSAT2=CSATfunc.offset( portalid=portalid,DT=DT,offi=offi)
      task_CSAT3=task_CSAT2[[2]]
    }else{
      task_CSAT2=CSATfunc.offset( portalid=portalid,DT=DT,offi=offi)
      task_CSAT3=rbind(task_CSAT3,task_CSAT2[[2]])
    }
    
    if(task_CSAT2[[1]]==F){ break 
    }else{
      offi=offi+1
    }
  }
  
  
  return(data.frame(DT,portalid, task_CSAT3  ))
}

#remove SilverScript
BU_id=BU_id[BU_id != 8844123]

Forsee_CSAT=CSATfunc(BU_id[1])
for( i in 2: length(BU_id)){
  Forsee_CSAT=rbind( Forsee_CSAT,
                     CSATfunc(BU_id[i])
  )}

names(Forsee_CSAT)[2]='BU_ID'

Forsee_CSAT= Forsee_CSAT[!is.na(Forsee_CSAT$CSAT),]


##########################################
###Silver Script####
##########################################
CSATfunc.offset<-function( portalid,DT=pulldate,offi=offi){
  
  url = "https://api.foresee.com/v1/token"
  r <- httr::POST(url, add_headers( 
    authorization= "Basic RDgzcURwa3czcDNkUW1CcW5Kc2FDM0RneEpDbEx6dDI6RDRrMWt0ZlpSN21ERmtwcVZsT0I="
  ),
  query =list(scope="r_cx_basic",grant_type="client_credentials")
  )
  api_call_headers=paste0('Bearer ',content(r)$access_token)
  
  
  url4 =  paste0("https://api.foresee.com/v1/measures/", portalid ,"/data")  
  r2 <-  httr::GET(url4, add_headers( 
    Authorization= api_call_headers
  ) ,query =list(from=pulldate , to=DT , offset=offi   ) )
  it=content(r2)$items
  nreps=length(it)
  
  if(nreps>0){
    
    RDID=rep(NA,nreps)
    for( i in 1:nreps){
      RDID[i]=content(r2)$items[[i]]$id
    }
    
    
    CSAT=rep(NA,nreps)
    for( i in 1:nreps){
      ll=content(r2)$items[[i]]$latentScores
      lld <- lapply(ll, as.character)
      ll_ind=max( -99, which(sapply(lld, FUN=function(X)  "SATISFACTION"  %in% X))[1] , 
                  na.rm =T 
      )
      if(ll_ind==-99){ CSAT[i]='NA'  }else{
        CSAT[i]= unlist(ll[ll_ind][[1]]$score ) }
    }
    CSAT=as.numeric(CSAT)
    
    primary_task_mb=rep(NA,nreps)
    for( i in 1:nreps){
      ll=content(r2)$items[[i]]$responses
      lld <- lapply(ll, as.character)
      ll_ind_mb=max( -99, which(sapply(lld, FUN=function(X)  "Primary reason Member"  %in% X))[1] ,
                     na.rm =T 
      )
      if(ll_ind_mb>0){     primary_task_mb[i] =substr(ll[ll_ind_mb][[1]][6],7,7)  }else{ primary_task_mb[i]=1000 }
    }  
    primary_task_mb=as.numeric(paste0(8,primary_task_mb))
    primary_task_sp=rep(NA,nreps)
    for( i in 1:nreps){
      ll=content(r2)$items[[i]]$responses
      lld <- lapply(ll, as.character)
      ll_ind_sp=max( -99, which(sapply(lld, FUN=function(X)  "Primary reason Shoppers"  %in% X))[1] ,
                     na.rm =T 
      )
      if(ll_ind_sp>0){     primary_task_sp[i] =substr(ll[ll_ind_sp][[1]][6],7,7)  }else{ primary_task_sp[i]=1000 }
      
    }  
    primary_task_sp=as.numeric(paste0(9,primary_task_sp))
    
    primary_task=pmin(primary_task_mb,primary_task_sp)
    
    
    
    Task_Accomplish=rep(NA,nreps)
    for( i in 1:nreps){
      ll=content(r2)$items[[i]]$responses
      lld <- lapply(ll, as.character)
      ll_ind=max( -99, which(sapply(lld, FUN=function(X)  "Task Accomplish - Members"  %in% X))[1] ,
                  which(sapply(lld, FUN=function(X)  "Task Accomplishment"  %in% X))[1] ,
                  na.rm =T 
      )
      if(ll_ind==-99){ Task_Accomplish[i]=0  }else{
        Task_Accomplish[i]=(ll[ll_ind][[1]]$answers=="1")*1  }
    } 
    
    
    os=rep(NA,nreps)
    for( i in 1:nreps){
      ll=content(r2)$items[[i]]$responses
      lld <- lapply(ll, as.character)
      ll_ind=max( -99, which(sapply(lld, FUN=function(X)  "os"  %in% X))[1] , 
                  na.rm =T 
      )
      if(ll_ind==-99){ os[i]='NA'  }else{
        os[i]= unlist(ll[ll_ind][[1]]$answers ) }
    } 
    os=sub("^([[:alpha:]]*).*", "\\1",  os)
    
    Navigation=rep(NA,nreps)
    for( i in 1:nreps){
      ll=content(r2)$items[[i]]$latentScores
      lld <- lapply(ll, as.character)
      ll_ind=max( -99, which(sapply(lld, FUN=function(X)  "Navigation"  %in% X))[1] , 
                  na.rm =T 
      )
      if(ll_ind==-99){ Navigation[i]='NA'  }else{
        Navigation[i]= unlist(ll[ll_ind][[1]]$score ) }
    }
    Navigation=as.numeric(Navigation)
    
    task_CSAT=data.table(RDID,primary_task,CSAT,Task_Accomplish,os,Navigation)
    
    hasMore=content(r2)$hasMore
  }else{
    hasMore=F
    task_CSAT=data.table(NA,NA,NA,NA,NA,NA)
    names(task_CSAT)=c('RDID', 'primary_task','CSAT','Task_Accomplish','os','Navigation')
  }
  
  return( list(hasMore, task_CSAT    ))
}

CSATfunc<-function( portalid,DT=pulldate){
  
  offi=0
  repeat {
    if(offi==0){
      task_CSAT2=CSATfunc.offset( portalid=portalid,DT=DT,offi=offi)
      task_CSAT3=task_CSAT2[[2]]
    }else{
      task_CSAT2=CSATfunc.offset( portalid=portalid,DT=DT,offi=offi)
      task_CSAT3=rbind(task_CSAT3,task_CSAT2[[2]])
    }
    
    if(task_CSAT2[[1]]==F){ break 
    }else{
      offi=offi+1
    }
  }
  
  return(data.frame(DT,portalid, task_CSAT3  ))
}


Forsee_CSAT_ss=CSATfunc(8844123) 

names(Forsee_CSAT_ss)[2]='BU_ID'

Forsee_CSAT_ss= Forsee_CSAT_ss[!is.na(Forsee_CSAT_ss$CSAT),]

Forsee_CSAT=rbind(Forsee_CSAT,Forsee_CSAT_ss)


#####################
# Loading the RODBC Package
#####################
library(RODBC)

Sys.setenv(ODBCINI = "/opt/teradata/client/ODBC_64/odbc.ini")

Sys.setenv(PATH = "/opt/teradata/client/16.00/bin:/usr/local/sbin:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.131-3.b12.el7_3.x86_64/bin:/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/bin:/opt/teradata/client/ODBC_64:/usr/local/bin")

driver='/opt/teradata/client/ODBC_64/lib/tdata.so'
user='cea_user'
password='makem0ney4cvs'
channel<-odbcConnect("testpbm",uid= user,pwd=password) 


#CREATE MULTISET TABLE DSS_CEA2.YX_Foresee_CSAT_Raw
#(   DT DATE,  BU_ID INT,  RDID VARCHAR(25), primary_task INT,    CSAT float, Task_Accomplish INT,
#  os VARCHAR(20))

deletesql1=paste0("Delete from DSS_CEA2.YX_Foresee_CSAT_Raw where DT=date'", pulldate,"'"  )
sqlQuery(channel, deletesql1)

#####################
# Write to teradata table(s)
#####################
sqlSave(channel, Forsee_CSAT , tablename = "DSS_CEA2.YX_Foresee_CSAT_Raw",rownames=FALSE, append=TRUE,fast = T,verbose=T)


#####################
# aggregate table(s)
#####################
deletesql2=paste0("Delete from DSS_CEA2.YX_Foresee_CSAT_report where DT=date'", pulldate,"'"  )
sqlQuery(channel, deletesql2)

sql3=paste0("insert  into DSS_CEA2.YX_Foresee_CSAT_report select date'", pulldate,"'  as  DT, BU_NAME ,  primary_task_answers as  Primary_task,    sum(case when a.BU_ID is not null then 1 else 0 end) AS Comments , average(csat ) as CSAT , sum(case when task_accomplish=1 then 1 else 0 end) as Vol_Task_Yes, average( case when task_accomplish=1 then csat else null end ) as CSAT_Task_Yes,
            sum(case when task_accomplish=0 then 1 else 0 end) as Vol_Task_No,
            average( case when task_accomplish=0 then csat else null end ) as CSAT_Task_No
            from  DSS_CEA2.YX_Foresee_Primary_task c left join DSS_CEA2.YX_Foresee_BU b  
            on b.BU_ID=c.BU_ID
            left join DSS_CEA2.YX_Foresee_CSAT_raw a on Primary_task=primary_task_value
            and c.BU_ID=a.BU_ID   
            and    dt = date'", pulldate,"' group by DT, BU_NAME  , primary_task_answers
            union
            select   DT, BU_NAME ,  'Overall' as Primary_task, count(*) AS Comments , 
            average(csat ) as CSAT , 
            sum(case when task_accomplish=1 then 1 else 0 end) as Vol_Task_Yes,
            average( case when task_accomplish=1 then csat else null end ) as CSAT_Task_Yes,
            sum(case when task_accomplish=0 then 1 else 0 end) as Vol_Task_No,
            average( case when task_accomplish=0 then csat else null end ) as CSAT_Task_No
            from DSS_CEA2.YX_Foresee_CSAT_raw a,
            DSS_CEA2.YX_Foresee_BU b 
            where a.BU_ID=b.BU_ID  
            and dt  = date'", pulldate,"' group by DT, BU_NAME  ,'Overall' "    )
sql3=gsub("[\r\n]", " ", sql3)

sqlQuery(channel, sql3)



close(channel)

