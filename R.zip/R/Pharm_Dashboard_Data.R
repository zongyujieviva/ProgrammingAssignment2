library ("dplyr")
library ("sqldf")
library ("RSiteCatalyst")
library(RODBC)
rm(list = ls())
##Start_Date <- as.Date("2017-12-31")
Start_Date <- Sys.Date()-3
End_Date <- Sys.Date()-1
SQL_Start_Date <- paste0("date'",Start_Date,"'")
SQL_End_Date <- paste0("date'",End_Date,"'")
cdtt=paste0("date'",End_Date,"'")
dcdtt=paste(cdtt,",", collapse="")
dcdttc=substr(dcdtt,1,nchar(dcdtt)-1)


Sys.setenv(ODBCINI = "/opt/teradata/client/ODBC_64/odbc.ini")
Sys.setenv(PATH = "/opt/teradata/client/16.00/bin:/usr/local/sbin:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.131-3.b12.el7_3.x86_64/bin:/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/bin:/opt/teradata/client/ODBC_64:/usr/local/bin")
driver='/opt/teradata/client/ODBC_64/lib/tdata.so'
user='cea_user'
password='makem0ney4cvs'
channel<-odbcConnect("testpbm",uid= user,pwd=password) 

adobesql=paste0("select DT,Desktop_Traffic,Desktop_Orders,Desktop_Refills,
mWeb_Traffic,mWeb_Orders,mWeb_Refills,App_Traffic,App_Orders,App_Refills,
Ipad_Fills,ES_Refills,Rapid_Fills
                from  DSS_CEA2.YZ_CVS_FLASH_DAILY where  dt between date-3 and date-1
                order by DT" )
adobesql=gsub("[\r\n]", " ", adobesql)

csatsql=paste0("select DT,
max(case when Primary_task = 'Overall' then CSAT else 0 end) as CSAT_Overall,
max(case when Primary_task = 'Overall' then Comments else 0 end) as Comments_Overall,
max(case when Primary_task = 'Refill existing prescription(s)' then CSAT else 0 end) as CSAT_Refill,
max(case when Primary_task = 'Refill existing prescription(s)' then Comments else 0 end) as Comments_Refill,
max(case when Primary_task = 'Transfer a prescription from a non-CVS pharmacy' then CSAT else 0 end) as CSAT_Transfer,
max(case when Primary_task = 'Transfer a prescription from a non-CVS pharmacy' then Comments else 0 end) as Comments_Transfer,
max(case when Primary_task = 'Manage automatic refill settings' then CSAT else 0 end) as CSAT_RF,
max(case when Primary_task = 'Manage automatic refill settings' then Comments else 0 end) as Comments_RF,
max(case when Primary_task = 'Add family/caregiver to my cvs.com account' then CSAT else 0 end) as CSAT_CG,
max(case when Primary_task = 'Add family/caregiver to my cvs.com account' then Comments else 0 end) as Comments_CG,
max(case when Primary_task = 'Add prescription access to my CVS.com account' then CSAT else 0 end) as CSAT_Auth,
max(case when Primary_task = 'Add prescription access to my CVS.com account' then Comments else 0 end) as Comments_Auth
                from  DSS_CEA2.YX_FORESEE_CSAT_REPORT where  dt >= date'2017-12-31' and BU_name = 'CVS Pharmacy'
               group by 1 
               order by DT" )
csatsql=gsub("[\r\n]", " ", csatsql)

table1=sqlQuery(channel, adobesql)
table3=sqlQuery(channel, csatsql)

close(channel)

user='YZONG'
password='Con_1001'
channel<-odbcConnect("testfs",uid= user,pwd=password) 

tewsql=paste0("select status_date(date) as DT,
count(distinct case when status = 'Picked Up' then order_no else '' end) as PP_Orders
from
(select order_no,line_type,min(s1.status_date) as create_time,st.description as status,min(s2.status_date) as status_date,l.shipnode_key,h.original_total_amount,h.bill_to_id
from p_doms.yfs_order_header h,p_doms.yfs_order_release_status s1,p_doms.yfs_order_release_status s2,business_users.lb_yfs_status st,p_doms.yfs_order_line l
where s1.status='1100' and s2.status_quantity>0 
and s1.order_header_key=h.order_header_key and s2.order_header_key=h.order_header_key
and document_type='0001' and entry_type='DOTM' and s1.createts>'2017-12-31 00:00:00' 
and s1.order_line_key=s2.order_line_key and st.process_type_key='ORDER_FULFILLMENT' 
and st.status=s2.status and l.order_line_key=s1.order_line_key
group by order_no, line_type,description,l.shipnode_key,h.original_total_amount,h.bill_to_id) a
where LINE_TYPE = 'ETW'
group by 1
order by 1" )
tewsql=gsub("[\r\n]", " ", tewsql)
table22=sqlQuery(channel, tewsql)
tewsql=paste0("select create_time(date) as DT,
count(distinct order_no ) as PP_ALL_Orders
              from
              (select order_no,line_type,min(s1.status_date) as create_time,st.description as status,min(s2.status_date) as status_date,l.shipnode_key,h.original_total_amount,h.bill_to_id
              from p_doms.yfs_order_header h,p_doms.yfs_order_release_status s1,p_doms.yfs_order_release_status s2,business_users.lb_yfs_status st,p_doms.yfs_order_line l
              where s1.status='1100' and s2.status_quantity>0 
              and s1.order_header_key=h.order_header_key and s2.order_header_key=h.order_header_key
              and document_type='0001' and entry_type='DOTM' and s1.createts>'2017-12-31 00:00:00' 
              and s1.order_line_key=s2.order_line_key and st.process_type_key='ORDER_FULFILLMENT' 
              and st.status=s2.status and l.order_line_key=s1.order_line_key
              group by order_no, line_type,description,l.shipnode_key,h.original_total_amount,h.bill_to_id) a
              where LINE_TYPE = 'ETW'
              group by 1
              order by 1" )
tewsql=gsub("[\r\n]", " ", tewsql)
table23=sqlQuery(channel, tewsql)
close(channel)
table2 <- left_join(table22, table23, by= c("DT"))

SCAuth("yzong:CVS Health","ba9be9678ba82cfad06913cab927ef1e",company="CVS Health")
page1 <- QueueTrended("cvshealthretailprod",
                     Start_Date,
                     End_Date,
                         c("visits"),
                         c("prop3","evar41"),
                         segment.id = c("s300002782_599c7c0217a0459e6c5e9b8d","s300002782_5a1469b5f73f233ba1a02db1"),
                    selected = c("rx: dashboard","rx dashboard: rx list","rx:transfer selector modal page","rx: financial summary","rx: dashboard: new rx","rx: current drug list",
                                 "rx: order history","readyfill:automatic refill settings","rx:pharmacysettings:manage family members","rx: transfer: transfer confirmation"
                                 ),
                    date.granularity = "day"
)
page2 <- QueueTrended("cvshealthretailprod",
                     Start_Date,
                     End_Date,
                     c("visits"),
                     c("prop3","evar41"),
                     segment.id = c("s300002782_5a1469b5f73f233ba1a02db1"),
                     selected = c("rx: digital order tracking: main page","nw:common cart","nw:order confirmation","neverwait|rx summary"),
                     date.granularity = "day"
)
page <- rbind(page1,page2)
page3 <- QueueTrended("cvshealthretailprod",
                      Start_Date,
                      End_Date,
                      c("visits"),
                      c("prop3","evar41"),
                      segment.id = c("s300002782_599c7c0217a0459e6c5e9b8d","s300002782_5aac07fd3f1e927d16e50d58"),
                      selected = c("rx: transfer: pharmacy information","rx: transfer: transfer confirmation"),
                      date.granularity = "day"
)
page4 <- QueueTrended("cvshealthretailprod",
                      Start_Date,
                      End_Date,
                      c("cm300002782_5b4e1633f118f05f8705c8f3","cm300002782_5b4e176321d4777234f337dd","cm300002782_5b1e914a3f1e9237605b25f9",
                        "cm300002782_5b62173b535e3b179aa931f0","cm300002782_5b621e4d8f0c657ed6714b37"),
                      c("domain"),
                      segment.id = c("s300002782_5a1469b5f73f233ba1a02db1"),
                      date.granularity = "day"
)
page5 <- QueueTrended("cvshealthretailprod",
                      Start_Date,
                      End_Date,
                      c("visits"),
                      c("prop3"),
                      segment.id = c("s300002782_5a1469b5f73f233ba1a02db1","s300002782_59c412f8b0178517a9c043cb"),
                      selected = c("promo: join extracare pharmacy & health rewards - cvs pharmacy","promo: extracare pharmacy & health rewards patient opt out",
                                   "promo: multi-dose medications","rx: mdp: patient caregiver information","rx: mdp: enrollment success page"),
                      date.granularity = "day"
)
page6 <- QueueTrended("cvshealthretailprod",
                      Start_Date,
                      End_Date,
                      c("event83","cm300002782_5abe7377ec83505b3e446594"),
                      c("evar41"),
                      segment.id = c("s300002782_5aa7f3a5c477fc1701400dc6"),
                      date.granularity = "day"
)
page$DT <- as.Date(page$datetime)
page <- page[ , !(names(page) %in% c("datetime","segment.id","segment.name"))]
page3$DT <- as.Date(page3$datetime)
page4$DT <- as.Date(page4$datetime)
page5$DT <- as.Date(page5$datetime)
page6$DT <- as.Date(page6$datetime)
page3 <- page3[ , !(names(page3) %in% c("datetime","segment.id","segment.name"))]
page4 <- page4[ , !(names(page4) %in% c("datetime","segment.id","segment.name","url"))]
page5 <- page5[ , !(names(page5) %in% c("datetime","segment.id","segment.name","url"))]
page6 <- page6[ , !(names(page6) %in% c("datetime","segment.id","segment.name","url"))]
page_daily1<- sqldf("select 
                     DT,
                     sum(CASE WHEN prop3 = 'rx: dashboard' and evar41='dweb' then visits else 0 end) as Rx_Dash_dweb,
                     sum(CASE WHEN prop3 = 'rx: dashboard' and (evar41 = 'mweb' or evar41 = 'tweb') then visits else 0 end) as Rx_Dash_mweb,
                     sum(CASE WHEN prop3 = 'rx: dashboard' and evar41='mapp' then visits else 0 end) as Rx_Dash_mapp,
                     sum(CASE WHEN prop3 = 'rx dashboard: rx list' and evar41='dweb' then visits else 0 end) as Rx_List_dweb,
                     sum(CASE WHEN prop3 = 'rx dashboard: rx list' and evar41 in ('mweb','tweb') then visits else 0 end) as Rx_List_mweb,
                     sum(CASE WHEN prop3 = 'rx dashboard: rx list' and evar41='mapp' then visits else 0 end) as Rx_List_mapp,
                     sum(CASE WHEN prop3 = 'rx:transfer selector modal page' and evar41='dweb' then visits else 0 end) as Trans_Start_dweb,
                     sum(CASE WHEN prop3 = 'rx:transfer selector modal page' and evar41 in ('mweb','tweb') then visits else 0 end) as Trans_Start_mweb,
                     sum(CASE WHEN prop3 = 'rx:transfer selector modal page' and evar41='mapp' then visits else 0 end) as Trans_Start_mapp,
                     sum(CASE WHEN prop3 = 'rx: transfer: transfer confirmation' and evar41='dweb' then visits else 0 end) as Trans_Success_dweb,
                     sum(CASE WHEN prop3 = 'rx: transfer: transfer confirmation' and evar41 in ('mweb','tweb') then visits else 0 end) as Trans_Success_mweb,
                     sum(CASE WHEN prop3 = 'rx: transfer: transfer confirmation' and evar41='mapp' then visits else 0 end) as Trans_Success_mapp,
                     sum(CASE WHEN prop3 = 'rx: financial summary' and evar41='dweb' then visits else 0 end) as Rx_Fin_dweb,
                     sum(CASE WHEN prop3 = 'rx: financial summary' and evar41 in ('mweb','tweb') then visits else 0 end) as Rx_Fin_mweb,
                     sum(CASE WHEN prop3 = 'rx: financial summary' and evar41='mapp' then visits else 0 end) as Rx_Fin_mapp,
                     sum(CASE WHEN prop3 = 'rx: dashboard: new rx' and evar41='dweb' then visits else 0 end) as Rx_New_dweb,
                     sum(CASE WHEN prop3 = 'rx: dashboard: new rx' and evar41 in ('mweb','tweb') then visits else 0 end) as Rx_New_mweb,
                     sum(CASE WHEN prop3 = 'rx: dashboard: new rx' and evar41='mapp' then visits else 0 end) as Rx_New_mapp,
                     sum(CASE WHEN prop3 = 'rx: current drug list' and evar41='dweb' then visits else 0 end) as Rx_Print_dweb,
                     sum(CASE WHEN prop3 = 'rx: current drug list' and evar41 in ('mweb','tweb') then visits else 0 end) as Rx_Print_mweb,
                     sum(CASE WHEN prop3 = 'rx: current drug list' and evar41='mapp' then visits else 0 end) as Rx_Print_mapp,
                     sum(CASE WHEN prop3 = 'rx: order history' and evar41='dweb' then visits else 0 end) as Rx_Hist_dweb,
                     sum(CASE WHEN prop3 = 'rx: order history' and evar41 in ('mweb','tweb') then visits else 0 end) as Rx_Hist_mweb,
                     sum(CASE WHEN prop3 = 'rx: order history' and evar41='mapp' then visits else 0 end) as Rx_Hist_mapp,
                     sum(CASE WHEN prop3 = 'readyfill:automatic refill settings' and evar41='dweb' then visits else 0 end) as Rx_RF_dweb,
                     sum(CASE WHEN prop3 = 'readyfill:automatic refill settings' and evar41 in ('mweb','tweb') then visits else 0 end) as Rx_RF_mweb,
                     sum(CASE WHEN prop3 = 'readyfill:automatic refill settings' and evar41='mapp' then visits else 0 end) as Rx_RF_mapp,
                     sum(CASE WHEN prop3 = 'rx:pharmacysettings:manage family members' and evar41='dweb' then visits else 0 end) as Rx_CG_dweb,
                     sum(CASE WHEN prop3 = 'rx:pharmacysettings:manage family members' and evar41 in ('mweb','tweb') then visits else 0 end) as Rx_CG_mweb,
                     sum(CASE WHEN prop3 = 'rx:pharmacysettings:manage family members' and evar41='mapp' then visits else 0 end) as Rx_CG_mapp,
                     sum(CASE WHEN prop3 = 'RX: DIGITAL ORDER TRACKING: MAIN PAGE' then visits else 0 end) as DOTM,
                     sum(CASE WHEN prop3 = 'nw:common cart' and evar41 in ('mweb','tweb') then visits else 0 end) as NW_Start_mweb,
                     sum(CASE WHEN prop3 = 'nw:common cart' and evar41 ='mapp' then visits else 0 end) as NW_Start_mapp,
                     sum(CASE WHEN prop3 = 'nw:order confirmation' and evar41 in ('mweb','tweb') then visits else 0 end) as NW_Success_mweb,
                     sum(CASE WHEN prop3 = 'nw:order confirmation' and evar41 ='mapp' then visits else 0 end) as NW_Success_mapp
                     from page
                     group by 1
                     order by 1")
page_daily3<- sqldf("select 
                     DT,
                   sum(CASE WHEN prop3 = 'rx: transfer: pharmacy information' then visits else 0 end) as Trans_Start_New,
                   sum(CASE WHEN prop3 = 'rx: transfer: transfer confirmation' then visits else 0 end) as Trans_Success_New
                   from page3
                   group by 1
                   order by 1")
page_daily4<- sqldf("select 
                     DT,
                   sum(cm300002782_5b4e1633f118f05f8705c8f3) as ETW_Option,
                   sum(cm300002782_5b4e176321d4777234f337dd) as DLY_Option
                   from page4
                   group by 1
                   order by 1")
page_daily5<- sqldf("select 
                     DT,
                   avg(cm300002782_5b1e914a3f1e9237605b25f9)/100 as Conv_on_NWclick,
                   sum(cm300002782_5b62173b535e3b179aa931f0) as RF_OptIn_Click,
                   sum(cm300002782_5b621e4d8f0c657ed6714b37) as RF_OptOut_Click
                   from page4
                   group by 1
                   order by 1")
page_daily6<- sqldf("select 
                     DT,
                    sum(CASE WHEN prop3 = 'RX: DIGITAL ORDER TRACKING: MAIN PAGE' and evar41='mweb' then visits else 0 end) as DOTM_mWeb,
                    sum(CASE WHEN prop3 = 'neverwait|rx summary' then visits else 0 end) as RX_Sumry_App
                    from page
                    group by 1
                    order by 1")
page_daily7<- sqldf("select 
                     DT,
                    sum(CASE WHEN name = 'PROMO: Join ExtraCare Pharmacy & Health Rewards - CVS pharmacy' then visits else 0 end) as PHR_Start,
                    sum(CASE WHEN name = 'PROMO: ExtraCare Pharmacy & Health Rewards Patient Opt Out' then visits else 0 end) as PHR_Success,
                    sum(CASE WHEN name = 'PROMO: Multi-Dose Medications' then visits else 0 end) as MDP_Landing,
                    sum(CASE WHEN name = 'rx: mdp: patient caregiver information' then visits else 0 end) as MDP_Form,
                    sum(CASE WHEN name = 'rx: mdp: enrollment success page' then visits else 0 end) as MDP_Success
                    from page5
                    group by 1
                    order by 1")
page_daily8<- sqldf("select 
                     DT,
                    sum(event83) as Coupon_Applied,
                    sum(cm300002782_5abe7377ec83505b3e446594) as Coupon_Info
                    from page6
                    group by 1
                    order by 1")
page_daily <- left_join(page_daily1, page_daily3, by= c("DT")) %>% left_join(.,page_daily4, by=c("DT")) 
new_add <- left_join(page_daily6,page_daily5, by=c("DT")) %>% left_join(.,page_daily7, by=c("DT")) %>% left_join(.,page_daily8, by=c("DT"))
user='YZONG'
password='Con_1001'
channel<-odbcConnect("testfs",uid= user,pwd=password) 

tewsql=paste0("select act_crt_ts(date) as DT,count(distinct transaction_id) as MPP_Transactions
from business_users.cvs_pay_txn_funnel_pivot
              where  lower(trim(txn_status)) = 'complete' and trim(fail_reason) = '0'
              and MPP_IND = 'Y'
              and act_crt_ts(date) between date-9 and date-1
              group by 1
              order by 1" )
tewsql=gsub("[\r\n]", " ", tewsql)
table5=sqlQuery(channel, tewsql)
tewsql=paste0("select REL_AUTH_TS(date) as DT,
count(distinct case when REL_AUTH_SRC_CD = 'Digital' then CRGVEE_RXC_PTNT_ID else NULL end) as CG_Relations_DTL,
count(distinct case when REL_AUTH_SRC_CD = 'Retail' then CRGVEE_RXC_PTNT_ID else NULL end) as CG_Relations_RTL,
count(distinct case when REL_AUTH_SRC_CD = 'Digital' and CRGVEE_TYP_CD = 1 then CRGVEE_RXC_PTNT_ID else NULL end) as CG_Relations_DTL_Adult
from idw_Product_development_s_bc.SEM_FACT_CAREGIVING_REL a
where REL_STUS_CD = '1'
and REL_AUTH_TS(date) between date-9 and date-1
group by 1
order by 1" )
tewsql=gsub("[\r\n]", " ", tewsql)
table6=sqlQuery(channel, tewsql)
close(channel)
table5$DT <- as.Date(table5$DT)
FinalOutput <- left_join(table1, table2, by= c("DT")) %>%
  left_join(.,table5, by=c("DT")) %>% left_join(.,table3, by=c("DT")) %>% 
  left_join(.,page_daily, by=c("DT")) %>% 
  left_join(.,table6, by=c("DT")) %>% left_join(.,new_add, by=c("DT"))

user='cea_user'
password='makem0ney4cvs'
channel<-odbcConnect("testpbm",uid= user,pwd=password) 

####################
# Delete 24 hours
####################
deletesql=paste0("Delete from DSS_CEA2.YZ_CVS_GEOFF_DAILY where dt >= date-3" )

sqlQuery(channel, deletesql)


#####################
# Write to teradata table(s)
#####################

sqlSave(channel, FinalOutput , tablename = "DSS_CEA2.YZ_CVS_GEOFF_DAILY",rownames=FALSE, append=TRUE,fast = T,verbose=T)

close(channel)
