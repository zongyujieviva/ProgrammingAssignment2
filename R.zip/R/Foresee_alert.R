library(RODBC)
library(data.table)

rm(list = ls())
setwd("/home/ronxu/Foresee")
lp=1

Foresee_BU=readRDS('Foresee_BU.rds')
Forsee_primary_task=data.table(readRDS('Forsee_primary_task.rds'))
BU_id=unique( Foresee_BU[Foresee_BU$active==T , 'BU_id'] )
pulldate=Sys.Date()-lp

Sys.setenv(ODBCINI = "/opt/teradata/client/ODBC_64/odbc.ini")

Sys.setenv(PATH = "/opt/teradata/client/16.00/bin:/usr/local/sbin:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.131-3.b12.el7_3.x86_64/bin:/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/bin:/opt/teradata/client/ODBC_64:/usr/local/bin")

driver='/opt/teradata/client/ODBC_64/lib/tdata.so'
user='cea_user'
password='makem0ney4cvs'
channel<-odbcConnect("testpbm",uid= user,pwd=password) 

#######################################################
##pull 7weeks data for the particular weekday
#######################################################
fssql=paste0("select DT,BU_ID, primary_task, csat, task_accomplish
from DSS_CEA2.YX_Foresee_CSAT_raw a, 
Sys_Calendar.Calendar b
where DT between (current_date-7*7-",lp,") and (current_date-",lp,")
and calendar_date=DT 
and day_of_week in ( select day_of_week 
from Sys_Calendar.Calendar where calendar_date=(current_date-",lp,")  )" 
)
fssql=gsub("[\r\n]", " ", fssql)
table1=data.table(sqlQuery(channel, fssql))
close(channel)

#######################################################
##calculate the lower bound to find out which BU sig lower
#######################################################
table1[,curr_ind:= (DT==pulldate)*1  ]
volcounts=table1[curr_ind==1, .N , BU_ID ]
listbu_2=volcounts[N>2 , BU_ID]
table1=table1[BU_ID %in% listbu_2,]


bu_curr_csat=table1[curr_ind==1,  list( curr_Vol=.N,  curr_Avg_CSAT=mean(CSAT), curr_CSAT_low=t.test( CSAT )$conf.int[1],curr_CSAT_upper=t.test( CSAT )$conf.int[2] ), 
                                  BU_ID ]

bu_p6w_csat=table1[curr_ind==0,  list( p6w_Vol=.N/7,  p6w_Avg_CSAT=mean(CSAT), p6w_CSAT_low=t.test( CSAT )$conf.int[1],p6w_CSAT_upper=t.test( CSAT )$conf.int[2] ), 
                    BU_ID ]

bu_csat=merge(bu_curr_csat,bu_p6w_csat,by="BU_ID")

bu_csat_siglow=bu_csat[curr_Avg_CSAT<p6w_CSAT_low  , ]
bu_csat_siglow[, vol_rate:= curr_Vol / p6w_Vol]
bu_csat_siglow[, curr_CSAT_range:= curr_CSAT_upper - curr_CSAT_low ]

#######################################################
##identify reason 1 and 2
#######################################################
bu_csat_siglow[ vol_rate<=0.6 ,reason:='r1']
bu_csat_siglow[ vol_rate>0.6 & curr_CSAT_range>=50 ,reason:='r2']

#######################################################
##redirect the unknown reasons
#######################################################
bu_csat_siglow1=bu_csat_siglow[is.na(reason),]

bu_csat_siglow[reason=='r1' , reason_txt:=paste0('The volumn, ',curr_Vol,', is much lower than average volumn ,',round(p6w_Vol), ', in previous 6 weeks.')  ]
bu_csat_siglow[reason=='r2' , reason_txt:=paste0('The daily average volumn,',round(p6w_Vol),', is too low, and the CSATs are too volatile. The CSAT cannot be trusted. ')  ]


#######################################################
##identify other reasons
#######################################################

pt_curr_csat=table1[curr_ind==1 & (BU_ID %in% bu_csat_siglow1[,BU_ID ])
                    ,  list( curr_Vol=.N,  curr_Avg_CSAT=mean(CSAT), curr_CSAT_std=sd( CSAT ) ), 
                    list(BU_ID,primary_task) ]

pt_p6w_csat=table1[curr_ind==0,  list( p6w_Vol=.N/7,  p6w_Avg_CSAT=mean(CSAT), p6w_CSAT_std=sd( CSAT )  ), 
                   list(BU_ID,primary_task) ]

pt_p6w_csat[ p6w_Vol>1 , p6w_lowb:=p6w_Avg_CSAT-1.96*p6w_CSAT_std/sqrt(p6w_Vol*7)  ]

bu_csat=merge(pt_curr_csat,pt_p6w_csat,by=c("BU_ID","primary_task" )  )

bu_csat1=bu_csat[ curr_Avg_CSAT<= p6w_lowb  ,]

names(Forsee_primary_task)[3]='primary_task'
names(Forsee_primary_task)[1]='BU_ID'

bu_csat1=merge(bu_csat1,Forsee_primary_task,by=c("BU_ID","primary_task" ),all.x=T  )

bu_csat1[ , reason:=  paste0('r',3:(2+nrow(bu_csat1))  ) ]

bu_csat1[, reason_txt := paste0('CSAT in task: (',primary_task_answers,') has dropped from ',round(p6w_Avg_CSAT),' to ',round(curr_Avg_CSAT)   )]
bu_csat1=bu_csat1[,list(BU_ID,reason,reason_txt)]

bu_csat_siglow1[ ,reason:=NULL]

bu_csat_siglow1=merge(bu_csat_siglow1,bu_csat1,by='BU_ID')

all_reasons=rbind(bu_csat_siglow[!is.na(reason) ,],bu_csat_siglow1)
all_reasons=all_reasons[,list(BU_ID ,curr_Vol,curr_Avg_CSAT,p6w_Vol,p6w_Avg_CSAT,reason_txt)]
all_reasons.df=data.frame(pulldate,all_reasons)
names(all_reasons.df)[1]='DT'

#################
#TABLE INSERT
#################
# CREATE MULTISET TABLE DSS_CEA2.YX_FORESEE_REASONS
# (  DT date, BU_ID INT, curr_Vol int, curr_Avg_CSAT FLOAT,
#   p6w_Vol FLOAT,
#   p6w_Avg_CSAT FLOAT,
#   reason_txt VARCHAR(1000)  
# )

channel<-odbcConnect("testpbm",uid= user,pwd=password) 

deletesql6=paste0("Delete from DSS_CEA2.YX_FORESEE_REASONS where DT=date'", pulldate,"'"  )
sqlQuery(channel, deletesql6)

sqlSave(channel, all_reasons.df , tablename = "DSS_CEA2.YX_FORESEE_REASONS",rownames=FALSE, append=TRUE,fast = T,verbose=T)
close(channel)
