library(openxlsx)
#####################
# Loading the RODBC Package
#####################
library(RODBC)

Sys.setenv(ODBCINI = "/opt/teradata/client/ODBC_64/odbc.ini")

Sys.setenv(PATH = "/opt/teradata/client/16.00/bin:/usr/local/sbin:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.131-3.b12.el7_3.x86_64/bin:/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/bin:/opt/teradata/client/ODBC_64:/usr/local/bin")

driver='/opt/teradata/client/ODBC_64/lib/tdata.so'
user='YZONG'
password='Con_1001'
channel<-odbcConnect("testfs",uid= user,pwd=password) 

tewsql=paste0("select order_no,line_type,min(s1.status_date) as create_time,st.description as status,min(s2.status_date) as status_date,l.shipnode_key,h.original_total_amount,count(1),h.bill_to_id
from p_doms.yfs_order_header h,p_doms.yfs_order_release_status s1,p_doms.yfs_order_release_status s2,business_users.lb_yfs_status st,p_doms.yfs_order_line l
where s1.status='1100' and s2.status_quantity>0 
and s1.order_header_key=h.order_header_key and s2.order_header_key=h.order_header_key
and document_type='0001' and entry_type='DOTM' and s1.createts>'2017-08-22 00:00:00' 
and s1.order_line_key=s2.order_line_key and st.process_type_key='ORDER_FULFILLMENT' 
and st.status=s2.status and l.order_line_key=s1.order_line_key
group by order_no, line_type,description,l.shipnode_key,h.original_total_amount,h.bill_to_id" )
tewsql=gsub("[\r\n]", " ", tewsql)
table1=sqlQuery(channel, tewsql)
close(channel)


setwd("/shared/Enterprise Digital Analytics/14 ICE/Never Wait")
wb<-loadWorkbook("OMS_Chelsey.xlsx") 
writeData(wb,"Sheet1",table1,startRow = 1,startCol = 2,colNames = TRUE)
saveWorkbook(wb,"OMS_Chelsey.xlsx",overwrite = T)