source("/home/ronxu/fs_store_header.R")


writequery="
  create table business_users.yx_localytics as  (
  select localytics_file_id,xtra_card_nbr, at_ts, uuid, session_uuid, name ,
  row_number() over (order by  session_uuid, at_ts) as click_ord
  from p_ent.localytic_event where cast(at_ts as date) ='2017-01-01'  
  and xtra_card_nbr is not null  
  ) WITH data 
PRIMARY INDEX ( uuid ) 
   "
sqlQuery(ch, paste(writequery))


writequery="
   create table business_users.yx_localytics2 as  (
  select a.session_uuid, substr(a.name,1,2) as name_short,
  (  (    extract(second from b.at_ts) + extract(minute from b.at_ts)*60 + extract(hour from b.at_ts)*3600 )
	-  
	(    extract(second from a.at_ts) + extract(minute from a.at_ts)*60 + extract(hour from a.at_ts)*3600 ) )
	as sec_diff, a.click_ord
  from business_users.yx_localytics a left join
  business_users.yx_localytics  b
  on a.session_uuid=b.session_uuid
  and (a.click_ord+1)  =b.click_ord
   ) WITH data 
PRIMARY INDEX ( session_uuid ) 
   "
sqlQuery(ch, paste(writequery))


  writequery="
  select SESSION_UUID, name_short||
 case when sec_diff is not null then '('||cast(sec_diff as varchar(3) )||')' else '' end
 as click, click_ord
from business_users.yx_localytics2
   "
clickstream0<-data.table(sqlQuery(ch, paste(writequery)))
  
  clickstream0<-clickstream0[order(click_ord),]
  
  clickstream0[,click_ord:=NULL]
  
clickstream<-  clickstream0[, lapply(.SD, paste0, collapse=""), by = SESSION_UUID]


write.csv(clickstream,"clickstream_data.csv",quote=F,na="",row.names = F)

