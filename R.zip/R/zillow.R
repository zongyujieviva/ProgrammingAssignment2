library(data.table)
library(xgboost) 
 

setwd("/home/ronxu/kg")

prop=fread("properties_2016.csv")
train0=fread("train_2016_v2.csv")


names(prop)
names(train0)

setkey(prop,parcelid)
setkey(train0,parcelid)

train<-merge(train0,prop,all.x=T)
dim(train)
length(train[,unique(parcelid)])
dim(train0)
length(train0[,unique(parcelid)])

twoparcels=train0[   , list(pnumber=.N)   ,parcelid][pnumber>1 ,]
train0[ parcelid %in%  twoparcels[,parcelid] ,]
#duplication due to sell in different times only 257

rm(prop)
gc()

train0[ order(month(transactiondate)),  .N, month(transactiondate) ]

# month     N
# 1:     1  6556
# 2:     2  6333
# 3:     3  8652
# 4:     4  9311
# 5:     5  9961
# 6:     6 10922
# 7:     7  9947
# 8:     8 10476
# 9:     9  9575
# 10:    10  4977
# 11:    11  1826
# 12:    12  1739
#ParcelId,201610,201611,201612,201710,201711,201712
names(train)

train[,tmonth:=month(transactiondate)]

dim(train)

View(train[, lapply(.SD, function(x) sum(is.na(x)) ), ])

length(train[, unique(propertyzoningdesc) ])#1997
head(train[,regionidneighborhood])

#feature engineering

#train[,cor(bathroomcnt,calculatedbathnbr,use="na.or.complete")]
 #bathroomcnt-calculatedbathnbr identical

train[is.na(threequarterbathnbr),threequarterbathnbr:=-99]

#train[ ,list(calculatedfinishedsquarefeet,finishedsquarefeet12)]
#train[ ,sqr_diff:=(calculatedfinishedsquarefeet-finishedsquarefeet12)]
#train[is.na(finishedsquarefeet12) ,list(calculatedfinishedsquarefeet,finishedsquarefeet12) ]
#calculatedfinishedsquarefeet has better data
#train[ ,finishedsquarefeet12:=NULL]
train[is.na(finishedsquarefeet12) ,finishedsquarefeet12:=-999]

#train[!is.na(calculatedfinishedsquarefeet) , 
#      lm(calculatedfinishedsquarefeet ~ bathroomcnt + bedroomcnt)]
# (Intercept)  bathroomcnt   bedroomcnt  
# -167.9        582.8        197.4 
#dim(train[is.na(calculatedfinishedsquarefeet),])
train[is.na(calculatedfinishedsquarefeet) , 
        calculatedfinishedsquarefeet:=-167.9+582.8*bathroomcnt +197.4*bedroomcnt ]
train[is.na(fullbathcnt),fullbathcnt:=-99]
train[,hottuborspa_ind:= (hashottuborspa=="true")*1]
#train[,mean(hottuborspa_ind) ]
train[,hashottuborspa:=NULL ]

#train[,.N,heatingorsystemtypeid ]
train[is.na(heatingorsystemtypeid),heatingorsystemtypeid:= -99]
train[,h_central:= (heatingorsystemtypeid==2)*1]
train[,h_na:= is.na(heatingorsystemtypeid ) *1]
train[,h_floor:= (heatingorsystemtypeid==7 )*1]
train[,h_fair:= (heatingorsystemtypeid==6)*1]
train[,h_solar:= (heatingorsystemtypeid==20)*1]
train[,h_none:= (heatingorsystemtypeid==13)*1]
train[,h_yes:= (heatingorsystemtypeid==24)*1]
train[,h_other:= (heatingorsystemtypeid %in% c(1,3:5,8:12,14:19,21:23,25))*1]


# train[, list(median(latitude),median(longitude) ) ]
# 34021500 -118173431


train[is.na(lotsizesquarefeet), list(lotsizesquarefeet,calculatedfinishedsquarefeet ) ]
train[ , log_left:=calculatedfinishedsquarefeet/lotsizesquarefeet]
train[is.na(log_left), log_left:=-9]

#train[,list(.N,mean( abs(logerror)), max(logerror), min(logerror) ),propertylandusetypeid][order(V2),]

train[,p_mix:= (propertylandusetypeid %in% c( 31,46,47))*1]
train[,p_mob:= (propertylandusetypeid %in% c( 263))*1]
train[,p_plex:= (propertylandusetypeid %in% c( 247:248))*1]
train[,p_coo:= (propertylandusetypeid %in% c( 267))*1]
train[,p_manu:= (propertylandusetypeid %in% c( 275))*1]
train[,p_cond:= (propertylandusetypeid %in% c( 264,266))*1]
train[,p_other:= (!(propertylandusetypeid %in% c( 264,266,261,31,46,47,
                                                263,247:248,267,275)))*1]
train[is.na(p_other),p_other:=1]
#same city how many sold
#citysold<-train[, list(city_sold=.N ) ,regionidcity] 
#citysold[,city_sold:= round(city_sold/90275,4)*1000]
saveRDS(citysold,"citysold")
train<-merge(train,citysold,by='regionidcity',all.x=T)


#zip code how long to sell
# library(lubridate)
# train[ ,length(unique(regionidzip))]#389
# ziptran<-train[ tmonth<10, 
#        list( transactiondate, regionidzip) ]
# ziptran<-ziptran[order(regionidzip,transactiondate),]
# ziptran[,nday:=yday(transactiondate) ]
# ziptran[,td_diff:=diff(nday)]
# longsell=ziptran[,list(long_sell=max(td_diff) ),regionidzip ]
saveRDS(longsell,"longsell")
train<-merge(train,longsell,by='regionidzip',all.x=T)

#replace propertyzoningdesc with pz_level
# propertyzon<-train[, list(pz_level=max( round(abs(logerror) )) ) ,propertyzoningdesc] 
# dim(train)
saveRDS(propertyzon,"propertyzon")
train<-merge(train,propertyzon,by='propertyzoningdesc',all.x=T)

# zipzon<-train[, list( 
#                      meaerror_level=mean( round(  logerror ,3 ))
#                      ) ,
#               list(regionidzip,propertyzoningdesc)]
saveRDS(zipzon,"zipzon")
train<-merge(train,zipzon,by=c('regionidzip','propertyzoningdesc'),all.x=T)

train[is.na(garagetotalsqft),garagetotalsqft:=-99 ]
 

lancode<-train[, list(  lancode_melevel=mean( round(  logerror ,3 ))
                     ) ,
               propertycountylandusecode ]
train<-merge(train,lancode,by= 'propertycountylandusecode',all.x=T)
 

 
zippro<-train[, list(maxerror_zplevel=max( round(  logerror ,3 )) 
                     ) ,
              list(regionidzip,propertycountylandusecode)]
train<-merge(train,zippro,by= c('regionidzip','propertycountylandusecode'),all.x=T)



citypro<-train[, list(meaerror_zplevel=mean( round(  logerror ,3 )) 
) ,
list(regionidcity,propertycountylandusecode)]
train<-merge(train,citypro,by= c('regionidcity','propertycountylandusecode'),all.x=T)



train[,m_garagecarcnt:=is.na(garagecarcnt)*1]
train[,m_fips:=is.na(fips)*1]
train[,m_fireplacecnt:=is.na(fireplacecnt)*1]
train[,m_numberofstories:=is.na(numberofstories)*1]
train[,m_airconditioningtypeid:=is.na(airconditioningtypeid)*1]
train[,m_architecturalstyletypeid:=is.na(architecturalstyletypeid)*1]
train[,m_basementsqft:=is.na(basementsqft)*1]
train[,m_buildingqualitytypeid:=is.na(buildingqualitytypeid)*1]
train[,m_buildingclasstypeid:=is.na(buildingclasstypeid)*1]
train[,m_decktypeid:=is.na(decktypeid)*1]
train[,m_finishedfloor1squarefeet:=is.na(finishedfloor1squarefeet)*1]
train[,m_finishedsquarefeet6:=is.na(finishedsquarefeet6)*1]
train[,m_finishedsquarefeet13:=is.na(finishedsquarefeet13)*1]
train[,m_finishedsquarefeet15:=is.na(finishedsquarefeet15)*1]
train[,m_finishedsquarefeet50:=is.na(finishedsquarefeet50)*1]
train[,m_garagetotalsqft:=is.na(garagetotalsqft)*1]
train[,m_poolcnt:=is.na(poolcnt)*1]
train[,m_poolsizesum:=is.na(poolsizesum)*1]
train[,m_pooltypeid10:=is.na(pooltypeid10)*1]
train[,m_pooltypeid2:=is.na(pooltypeid2)*1]
train[,m_pooltypeid7:=is.na(pooltypeid7)*1]
train[,m_propertycountylandusecode:=is.na(propertycountylandusecode)*1]
train[,m_rawcensustractandblock:=is.na(rawcensustractandblock)*1]
train[,m_censustractandblock:=is.na(censustractandblock)*1]
train[,m_regionidcounty:=is.na(regionidcounty)*1]
train[,m_regionidcity:=is.na(regionidcity)*1]
train[,m_roomcnt:=is.na(roomcnt)*1]
train[,m_storytypeid:=is.na(storytypeid)*1]
train[,m_typeconstructiontypeid:=is.na(typeconstructiontypeid)*1]
train[,m_unitcnt:=is.na(unitcnt)*1]
train[,m_yardbuildingsqft17:=is.na(yardbuildingsqft17)*1]
train[,m_yardbuildingsqft26:=is.na(yardbuildingsqft26)*1]
train[,m_yearbuilt:=is.na(yearbuilt)*1]
train[,m_taxdelinquencyflag:=is.na(taxdelinquencyflag)*1]
 
train[,garagecarcnt:=NULL]
train[,fips:=NULL]
train[,fireplacecnt:=NULL]
train[,numberofstories:=NULL]
train[,airconditioningtypeid:=NULL]
train[,architecturalstyletypeid:=NULL]
train[,basementsqft:=NULL]
train[,buildingqualitytypeid:=NULL]
train[,buildingclasstypeid:=NULL]
train[,decktypeid:=NULL]
train[,finishedfloor1squarefeet:=NULL]
train[,finishedsquarefeet6:=NULL]
train[,finishedsquarefeet13:=NULL]
train[,finishedsquarefeet15:=NULL]
train[,finishedsquarefeet50:=NULL]
train[,garagetotalsqft:=NULL]
train[,poolcnt:=NULL]
train[,poolsizesum:=NULL]
train[,pooltypeid10:=NULL]
train[,pooltypeid2:=NULL]
train[,pooltypeid7:=NULL]
train[,propertycountylandusecode:=NULL]
train[,rawcensustractandblock:=NULL]
train[,censustractandblock:=NULL]
train[,regionidcounty:=NULL]
train[,regionidcity:=NULL]
train[,roomcnt:=NULL]
train[,storytypeid:=NULL]
train[,typeconstructiontypeid:=NULL]
train[,unitcnt:=NULL]
train[,yardbuildingsqft17:=NULL]
train[,yardbuildingsqft26:=NULL]
train[,yearbuilt:=NULL]
train[,taxdelinquencyflag:=NULL]

# train[,list(taxvaluedollarcnt,structuretaxvaluedollarcnt,
#             landtaxvaluedollarcnt,taxamount 
# )]


#options(scipen=999)
#train[ ,  lm(taxvaluedollarcnt~calculatedfinishedsquarefeet+bathroomcnt+bedroomcnt+lotsizesquarefeet)]
train[, govass_dif:=
  ( -14201+ 384*calculatedfinishedsquarefeet+
      83334*bathroomcnt-129913 *bedroomcnt+
      -0.08*lotsizesquarefeet)-taxvaluedollarcnt]


train[,  assessmentyear:=NULL]

train[is.na(taxdelinquencyyear),taxdelinquencyyear:=-9]
train[is.na(govass_dif),govass_dif:=9999999]

train[is.na(calculatedbathnbr),calculatedbathnbr:=-99]
train[is.na(fullbathcnt),fullbathcnt:=-99]
train[is.na(structuretaxvaluedollarcnt),structuretaxvaluedollarcnt:=-99]
train[is.na(taxvaluedollarcnt),taxvaluedollarcnt:=-99]
train[is.na(landtaxvaluedollarcnt),landtaxvaluedollarcnt:=-99]
train[,m_lot:=is.na(lotsizesquarefeet)*1]

train[,m_nerb:=is.na(regionidneighborhood)*1]

train[is.na(lotsizesquarefeet),lotsizesquarefeet:=-999]

train[,regionidzip:=NULL]
train[,propertyzoningdesc:=NULL]

train[,heatingorsystemtypeid:=NULL]
train[,regionidneighborhood:=NULL]


train[,firef:=(fireplaceflag=='true')*1]
train[,fireplaceflag:=NULL]
#END
names(train)


#View(train[, lapply(.SD, function(x) sum(is.na(x)) ), ])

sapply(train,is.numeric)[sapply(train,is.numeric)==F] 
 train[,list(fireplaceflag,p_other,m_lot ,m_nerb)]
#LOT - LIVING
 

 lel2<-c('meaerror_level',
 'maxerror_zplevel' ,
 'lancode_melevel')

 
 lel3<-c('meaerror_level',
         'maxerror_zplevel' ,
         'lancode_melevel'  )

zy<-as.numeric(train[,logerror ])




smp_size <- floor(0.85  * nrow(train))
train_ind <- sample(seq_len(nrow(train)), size = smp_size)

zXt<-as.matrix( train[train_ind,c(-3:-1),with=F] )
zXv<-as.matrix( train[-train_ind,c(-3:-1),with=F] )


zyt<-as.numeric(zy[train_ind ])
zyv<-as.numeric(zy[-train_ind ]) 
mean(zyt);mean(zyv) 

xgb <- xgboost(data =zXt , 
               label = zyt , 
               seed=2, sample_type='weighted',
               eta=0.02 ,
               nround=1000, 
               max_depth=3, 
               early_stopping_rounds = 10,
           
               objective = "reg:linear" ,
               eval_metric="mae"
)


names <- names(train[,c(-3:-1),with=F])
 
importance <- xgb.importance(lel3, model = xgb)
var_imp=head(importance,60)$Feature
var_imp2=var_imp[c(-2,-3,-15) ]
var_imp3=var_imp[c(-6,-8,-9,-10,-19) ]

zXt<-as.matrix( train[train_ind,lel3,with=F] )
zXv<-as.matrix( train[-train_ind,lel3,with=F] )



zyv_boost <- predict(xgb, zXv)
#library(Metrics)
Metrics::mae(zyv_boost,zyv)

zayt<-abs(zyt)
zayv<-abs(zyv)

axgb <- xgboost(data =zXt , 
               label = zayt , 
               seed=2, sample_type='weighted',
               eta=0.02 ,
               nround=500, 
               max_depth=4,
               min_child_weight=40,
               objective = "reg:linear" ,
               eval_metric="mae"
)
azyv_boost <- predict(axgb, zXv)
#library(Metrics)
Metrics::mae(azyv_boost,zayv)

xt2=cbind(  predict(xgb, zXt),predict(axgb, zXt) )

exgb <-lm(zyt~ . , data.frame(xt2))
xv2=cbind(  predict(xgb, zXv),predict(axgb, zXv) )
ezyv_boost <- predict(exgb, data.frame(xv2) ) 
Metrics::mae(ezyv_boost,zyv)


zpyt<- zyt>0*1
zpyv<-zyv>0*1
mean(zpyt);mean(zpyv);


 
p_boost <- predict(pxgb, zXv)
glmnet::auc(zpyv, p_boost)


xt2=cbind(  predict(xgb, zXt),predict(axgb, zXt),predict(pxgb, zXt) )
head(xt2)
exgb <- xgboost(data =xt2 , 
                label = zyt , 
                seed=2, sample_type='weighted',
                eta=0.2,
                nround=1000, 
                max_depth=4,
                subsample = 1,   
                early_stopping_rounds = 10,
                min_child_weight=40,
                colsample_bytree = 1,
                objective = "reg:linear" ,
                eval_metric="mae"
)

exgb <-lm(zyt~ . , data.frame(xt2))

xv2=cbind(  predict(xgb, zXv),predict(axgb, zXv),predict(pxgb, zXv) )

ezyv_boost <- predict(exgb, data.frame(xv2) ) 
#library(Metrics)
Metrics::mae(ezyv_boost,zyv)



sub=fread("sample_submission.csv")

 
