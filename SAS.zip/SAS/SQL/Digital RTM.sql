select WK_STRT_DT,count(distinct c.CLM_EVNT_GID)
from DWU_EDW.V_ECCA_INTRCTN a
join DWU_EDW.V_ECCA_MBR_TRX_DENORM b on a.intrctn_key_id=b.intrctn_key_id
join SB_AAE.V_AE_SCRPT_BSKT c on c.CLM_EVNT_GID = b.CLM_EVNT_GID
join DWU_EDW.V_DT_DAY d on d.PRD_DT = CRTE_DT
where  a.INTRCTN_TYP_CD in ('3040','3041','3042','3043','3050','3051')
and CRTE_DT between date'2014-12-28' and date'2016-01-30'
and c.FILL_DT between date'2014-12-28' and date'2016-01-30'
and ECCA_RFRNC_KEY_ID = 'RX_NUM'
and RX_RP_CHNL_STUS_CD = 'Channel Switch'
and CHNL_CD = 2 and CHNL_2_CD in (3,4,5,6,8,9,10)
group by 1