select evnt_id,count(*)as evnts
		from dss_clin.V_PRTL_LOG_DLY											
		where log_dt(date) between date'2014-06-01' and date'2014-06-30'									
				and evnt_id in ('LOGIN_FAILED',	'LOGIN_SUCCESSFUL')	
				and evnt_src in (1,3)
group by 1
