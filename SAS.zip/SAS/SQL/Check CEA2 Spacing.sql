SELECT DatabaseName ,SUM(CurrentPerm)/1024/1024 AS USEDSPACE_IN_MB ,
SUM(MaxPerm)/1024/1024 AS MAXSPACE_IN_MB ,
SUM(CurrentPerm)/ NULLIFZERO (SUM(MaxPerm)) *100 (FORMAT 'zz9.99%') AS Percentage_Used  ,
MAXSPACE_IN_MB- USEDSPACE_IN_MB AS REMAININGSPACE_IN_MB 
FROM DBC.DiskSpace 
WHERE DatabaseName = 'dss_cea2' GROUP BY DatabaseName; 
.