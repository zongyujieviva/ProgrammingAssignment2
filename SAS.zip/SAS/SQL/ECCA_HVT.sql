select distinct a.INTRCTN_TYP_CD, b.SRC_DESC_TXT , a.INTRCTN_RSLT_CD ,count(distinct ECCA_MBR_ID)as COUNTS ,  a.sys_id, b.RPT_DESC_TXT, CRTE_DT
from DWU_EDW.V_ECCA_INTRCTN a, DWU_EDW.V_ECCA_MTDAT b 
WHERE CRTE_DT(date) between date'2015-06-01' and date'2015-06-30' and
a.INTRCTN_TYP_CD = b.src_val_txt and
  a.INTRCTN_TYP_CD = '3070'
group by 1,3,5,2,6,7
order by 1,3