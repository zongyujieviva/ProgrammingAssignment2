select 					
count(distinct b.ql_bnfcy_id)	as mbrs				
from dwcorp2.V_MBR_ELIG_ACTIVE a					
join dwcorp2.v_mbr b					
on a.mbr_gid=b.mbr_gid					
join dss_clin.v_algn_lvl_denorm d					
on b.algn_lvl_gid=d.algn_lvl_Gid_key and date'2014-08-31'					
		between ALGN_GRP_EFF_DT(date) and ALGN_GRP_END_DT(date)			
					
left join (select  algn_lvl_gid					
	from pdm_app.V_PEERS_CONSOL 				
	where CL_TYPE in ('NONCLASS','RXA_MEDICAID','OFFSHORE'				
,'DO_NOT_USE','PERF SCRIPT','CASH CARD',					
'RXA_HEALTHPLAN','RXA_CASH CARD','RXA_EMPLOYER'					
,'UNCLASSIFIED','RXA_MEDICARE')					
	group by 1)e  on d.algn_lvl_gid_key=e.algn_lvl_gid				
					
join (select mbr_gid					
from dwcorp2.V_CLAIM_CMN_PAID t1					
	join dss_clin.v_drug_denorm  t2				
		on t1.drug_gid=t2.drug_gid			
  and dspnd_dt(date) between add_months(date'2014-08-01', -11) and date'2014-08-31'					
  and maint_ind='1'					
 --- and t1.PHMCY_GID in (4076015, 4071912,18557,30570,62166,66657,76751,83877,146897,166487,454004,454867) 					
  /*and t1.MAINT_CHOICE_IND is not null*/  /*mchoice scripts*/					
group by 1) m					
on b.mbr_gid=m.mbr_gid					

join (
select bnfcy_id
from dss_clin.v_pty_prfle 
where last_acs_ts(date) between date'2013-09-01' and date'2014-08-31'
and changed_ind='A'
group by 1
) p on b.ql_bnfcy_id=p.bnfcy_id
					
where date'2014-08-31' between a.ELIG_EFF_DT(date) and ELIG_END_DT(date)					
and ( a.SRC_SYS_CD='Q' or a.SRC_SYS_CD='X' or a.SRC_SYS_CD='R' )					
and e.algn_lvl_gid is null					
---and  MBR_BRTH_DT(date) < add_months(current_date,-18*12)