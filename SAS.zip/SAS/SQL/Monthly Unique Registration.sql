select extract(month from log_dt),
count(distinct bnfcy_id) as total
from dss_clin.v_prtl_log_dly
where evnt_id = 'USER_REGISTER_SUCCESS'
and log_dt >= date'2014-03-01'
and evnt_src ^= 1
group by 1