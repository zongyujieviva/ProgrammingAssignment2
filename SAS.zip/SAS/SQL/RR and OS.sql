select WK_STRT_DT, a.INTRCTN_TYP_CD, b.SRC_DESC_TXT , a.INTRCTN_RSLT_CD ,count(distinct a.INTRCTN_KEY_ID)as COUNTS
from DWU_EDW.V_ECCA_INTRCTN a, DWU_EDW.V_ECCA_MTDAT b , DWU_EDW.V_DT_DAY d

WHERE CRTE_DT(date) between date'2015-12-27' and date'2016-06-25' and
d.PRD_DT = CRTE_DT and
a.INTRCTN_TYP_CD = b.src_val_txt and
  a.sys_id = 'CMP'
and CHNL_TYP_CD in ('EMAIL','TEXT','PHONE')
group by 1,2,3,4