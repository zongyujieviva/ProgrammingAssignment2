select 	log_dt
,case when rx_nbr is null or rx_nbr=0 then 'NEW RX' else 'REFILL' end as new_refill
,count(distinct case when for_bnfcy_id is null or for_bnfcy_id=0 then cast(bnfcy_id as decimal(20,0))		
		 else for_bnfcy_id end ||NDC_NBR) AS SCRIPTS
from 		
DSS_CLIN.V_prtl_log_dly a
join ( select b.ql_bnfcy_id
	from dwcorp2.v_mbr b	
	 group by 1
	) t	
	on a.bnfcy_id=t.ql_bnfcy_id		
where evnt_id  ='CART_CONFIRM' and DLVRY_SYSTM=2 and log_dt(date) between 
	date'2014-08-01' and date'2014-08-31'	
group by 1,2