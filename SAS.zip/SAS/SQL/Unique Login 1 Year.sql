select count(distinct bnfcy_id)
from dss_clin.v_pty_prfle 
where last_acs_ts(date) between date'2013-09-01' and date'2014-08-31'
and changed_ind='A'