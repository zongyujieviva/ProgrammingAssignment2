select 
count(distinct ECCA_MBR_ID) as MBR_COUNTS from DWU_EDW.V_ECCA_INTRCTN a
where  a.INTRCTN_TYP_CD ='3163' and CRTE_DT between date'2016-04-24' and date'2016-05-21'
and INTRCTN_RSLT_CD = 'COMPLETED'