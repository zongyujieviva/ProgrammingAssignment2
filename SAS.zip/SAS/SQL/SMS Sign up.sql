select count(distinct BCO_BNFCY_ID)
	from dss_clin.v_bco_bnfcy_com_optn A
	where BCO_EFF_DT(date) between date'2015-11-01' and date'2015-11-30' and BCO_EXP_DT(date) > date'2015-11-30' 
	and bco_bnfcy_exc_ind = 0
	and BCO_PFE_AVC_CD in ('17','19')
	and BCO_PCI_CMM_ID in (1335,264)