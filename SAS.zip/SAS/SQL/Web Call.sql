select year_of_calendar, month_of_year 
, count (distinct cust_activity_id) as calls
from dss_cea.JC_DTW_Camps_Calls A
left join dss_cea2.jc_ptl_regdt B
on beneficiary_id=cast(b.bnfcy_id as decimal(11,0))
	and hsc_ts_dt(date)>regdt(date)
join sys_calendar.calendar D
on hsc_ts_dt(date)=D.calendar_date	
where hsc_ts_dt(date) between date'2014-01-01' and date'2014-08-31'
and B.bnfcy_id is not null
group by 1,2
