select sum(elig_cnt), sum(ELIG_INSRD_CNT), sum(ELIG_DPDNT_CNT),
sum(UTL_CNT),sum(UTL_INSRD_CNT),sum(UTL_DPNDT_CNT)
from dss_clin.v_elig_smry a,
dss_clin.v_algn_lvl_denorm b
where a.algn_lvl_gid=b.algn_lvl_gid_key and
elig_eff_dt(date) = date'2014-06-30' and
cust_nm is not null and
ql_clnt_id is not null and
date'2014-06-30' between algn_grp_eff_dt(date) and algn_grp_end_dt(date)