sel INTRCTN_RSLT_CD,count(*)
from DWU_EDW.V_ECCA_INTRCTN a
where INTRCTN_TYP_CD in ('3020','3021','3022') and CRTE_DT between date'2015-12-27' and date'2016-01-23'
group by 1
