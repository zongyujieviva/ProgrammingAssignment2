sel count(distinct ECCA_MBR_ID)
from DWU_EDW.V_ECCA_INTRCTN a
where INTRCTN_TYP_CD in ('260','2514','2515','263','2516','2517','1229','2518','2519') and CRTE_DT between date'2015-10-01' and date'2015-10-31'
and CHNL_TYP_CD in ('EMAIL','SECURE')
